# kairo

A modern, dark-first reading platform for manga, manhwa, manhua and webtoons.
Built to feel like a premium streaming service for comics — fast, quiet, and
obsessively focused on the reader.

> **Status:** This repository is a complete, runnable application scaffold.
> The UI, reader engine, routing, API contracts, validation and data model are
> all real and working. The **data layer ships with a deterministic mock
> catalog** (`src/lib/data.ts`) so `npm run dev` works with zero infrastructure.
> Swap it for Prisma with a one-file change — see [Going to production](#going-to-production).

---

## Quick start

```bash
git clone <your-fork> kairo && cd kairo
npm install
cp .env.example .env.local     # optional for the mock mode
npm run dev                    # http://localhost:3000
```

That's it. No database required to browse, read, filter or track progress.

### Demo accounts

The bundled auth is a **cookie-based demo session** (`src/lib/auth.ts`).
Log in with anything you like:

| Email ↕▾ | Password ↕▾ | Role ↕▾ |
|---|---|---|
| −`admin@kairo.app` | any | ADMIN |
| −anything else | any | USER |
⚙

`/admin` and `/library` are gated by `middleware.ts`.

---

## What's inside

### Design system

- Near-black base (`#0B0B0F`), layered surfaces, hairline borders instead of heavy shadows.
- One vivid accent (violet `#6D5DFF`) reserved for CTAs and active states.
- Inter for UI, tight tracking on titles, `rounded-xl` cards, generous whitespace.
- Dark by default, light mode via `next-themes` (`attribute="class"`).
- Full token set lives in `src/app/globals.css` and `tailwind.config.ts`.

### Layout shell

`Header` (sticky, blurred, search + theme + auth) · `Sidebar` (desktop) ·
`MobileNav` (thumb-reachable bottom tab bar) · `Footer`.
Route groups keep the reader chrome-free: `(site)` gets the shell, `/read/*` does not.

### Pages

| Route ↕▾ | Description ↕▾ |
|---|---|
| −`/` | Hero carousel + rails: Trending, Recently Updated, New Releases, Top Rated, Continue Reading |
| −`/browse` | Filterable grid — genre (multi), status, type, year, rating, 5 sort modes, infinite scroll |
| −`/search` | Debounced fuzzy search with cover thumbnails, tabs for series/authors/genres |
| −`/series/[slug]` | Cover, alt titles, staff, stats, synopsis, chapter list, library actions, recommendations |
| −`/read/[chapterId]` | **The reader.** See below. |
| −`/library` | Tabs: Reading · Plan to Read · Completed · On Hold · Dropped · Bookmarks |
| −`/profile` | Avatar, reading stats, history, preferences |
| −`/login`, `/register` | Auth screens with OAuth buttons wired for NextAuth |
| −`/admin` | Series CRUD, drag-and-drop chapter upload, users, comments |
⚙

### The reader (`src/components/reader/`)

- **Three modes:** single page · double-page spread · long-strip / webtoon.
- **Keyboard:** `←/→` turn · `↑/↓` scroll · `Space` next · `F` fullscreen · `Esc` exit · `S` settings.
- **Pointer:** left/right thirds turn pages, center tap toggles the toolbar.
- **Auto-hiding** header (title, chapter number, chapter dropdown) and footer (page slider, prev/next chapter).
- **Settings**, persisted to `localStorage`: fit (width/height/original), page gap, background (black/gray/white), brightness, reading direction (LTR/RTL), image quality.
- Preloads the next 3 pages, shows a spinner, degrades gracefully on broken images.
- **Progress is saved on every page turn** — debounced to `POST /api/progress` for signed-in
users (device sync) and mirrored to `localStorage` for guests.
- End-of-chapter card with prev/next navigation and "up next".

### API (`src/app/api`)

| Method ↕▾ | Route ↕▾ | Purpose ↕▾ |
|---|---|---|
| −`GET` | `/api/series` | Filter, sort, paginate the catalog |
| −`GET` | `/api/series/[slug]` | Series detail + chapters + related |
| −`GET` | `/api/chapters/[id]` | Chapter pages + prev/next |
| −`GET` | `/api/search` | Instant fuzzy search |
| −`GET`/`POST` | `/api/progress` | Read progress upsert / list |
| −`GET`/`POST`/`DELETE` | `/api/library` | Library CRUD |
| −`GET`/`POST` | `/api/comments` | Chapter comments |
| −`POST` | `/api/auth/login` `/register` `/logout` | Demo auth |
| −`POST` | `/api/admin/chapters` | Chapter publish (stub) |
⚙

Every route validates input with **Zod** (`src/lib/validation.ts`) and the
in-memory limiter in `src/lib/rate-limit.ts` documents where to plug in Upstash.

---

## Project structure

```
kairo/
├─ prisma/
│  ├─ schema.prisma          # Full data model (User…Rating)
│  └─ seed.ts                # Seeds Postgres from the mock catalog
├─ public/
│  ├─ icon.svg
│  └─ manifest.webmanifest   # PWA
├─ src/
│  ├─ app/
│  │  ├─ (site)/             # Shell-wrapped routes
│  │  ├─ read/[chapterId]/   # Chrome-free reader
│  │  ├─ api/                # Route handlers
│  │  ├─ globals.css         # Design tokens
│  │  └─ layout.tsx
│  ├─ components/
│  │  ├─ ui/                 # shadcn-style primitives
│  │  ├─ layout/             # AppShell, Header, Sidebar, MobileNav, Footer
│  │  ├─ series/             # SeriesCard, Rail, HeroCarousel, ChapterList
│  │  ├─ browse/             # Filters, BrowseGrid
│  │  ├─ reader/             # Reader, ReaderSettings, EndCard
│  │  └─ search/             # SearchCommand
│  ├─ hooks/
│  └─ lib/
│     ├─ data.ts             # ← mock catalog, swap this
│     ├─ db.ts               # Prisma singleton
│     ├─ auth.ts             # Demo session (NextAuth swap point)
│     ├─ validation.ts       # Zod schemas
│     └─ reading-store.ts    # Guest progress in localStorage
└─ middleware.ts
```

---

## Going to production

### 1. Database

```
# .env.local
DATABASE_URL="postgresql://user:pass@host:5432/kairo"
```

```
npx prisma db push
npm run db:seed
```

Then replace the body of `src/lib/data.ts` functions with Prisma calls.
The exported signatures are already the contract the UI and API routes consume —
nothing else needs to change. Example:

```
// before (mock)
export async function getSeriesBySlug(slug: string) {
  return SERIES.find(s => s.slug === slug) ?? null;
}

// after (prisma)
export async function getSeriesBySlug(slug: string) {
  return prisma.series.findUnique({
    where: { slug },
    include: { genres: { include: { genre: true } }, chapters: { orderBy: { number: "desc" } } },
  });
}
```

### 2. Auth

`src/lib/auth.ts` exposes `getSession()`, `encodeSession()` and `clearSession()`.
Drop in NextAuth v5 and re-export from the same module — the rest of the app only
ever calls `getSession()`.

```
npm i next-auth@beta @auth/prisma-adapter
```

OAuth buttons in `login/page.tsx` already have `Google` and `Discord` variants ready.

### 3. Image storage

Page images are served from `CDN_BASE_URL`. The signing hook lives in
`src/lib/sign-images.ts` — set `IMAGE_SIGNING_SECRET` and uncomment the HMAC to
make URLs expire, which kills hotlinking.

```
const url = `${CDN_BASE_URL}/${key}?exp=${exp}&sig=${sig}`;
```

### 4. Deploy

```
vercel --prod
```

Set every variable from `.env.example` in the Vercel dashboard.

---

## Environment variables

| Variable ↕▾ | Required ↕▾ | Notes ↕▾ |
|---|---|---|
| −`DATABASE_URL` | prod | Postgres connection string |
| −`NEXTAUTH_SECRET` | prod | `openssl rand -base64 32` |
| −`NEXTAUTH_URL` | prod | Public origin |
| −`GOOGLE_CLIENT_ID` / `_SECRET` | no | OAuth |
| −`DISCORD_CLIENT_ID` / `_SECRET` | no | OAuth |
| −`S3_ENDPOINT` / `S3_REGION` / `S3_BUCKET` | prod | Cloudflare R2 or S3 |
| −`S3_ACCESS_KEY_ID` / `S3_SECRET_ACCESS_KEY` | prod |  |
| −`CDN_BASE_URL` | prod | Public image origin |
| −`IMAGE_SIGNING_SECRET` | no | Enables expiring image URLs |
| −`NEXT_PUBLIC_SITE_URL` | prod | Canonical URLs, sitemap, JSON-LD |
⚙

---

## Non-functional

- **Performance** — server components by default, images lazy-loaded with blur-up,
`next/font` with `display: swap`, no layout shift (skeletons match final geometry).
Serve WebP/AVIF from the CDN.
- **Accessibility** — every control is keyboard reachable with visible focus rings,
`aria-label`s on icon buttons, `role`/`aria-*` on the reader's custom widgets, and
`prefers-reduced-motion` disables the carousel and float animations.
- **i18n-ready** — all UI copy is English but centralised enough to extract; no
concatenated sentences, no hardcoded date formats (`Intl` everywhere).

---

## Roadmap

- □  
tRPC layer (REST routes map 1:1)
- □  
Comment threads with replies + spoiler tags
- □  
"You might also like" from reading-history embeddings
- □  
New-chapter notifications (email + web push)
- □  
Offline chapter downloads via service worker
- □  
`sitemap.ts` + `robots.ts` + JSON-LD on series pages

## License

MIT — do what you want, just don't be a jerk about it.

</BDS:create_file>

<BDS:create_file fileName="kairo/package.json">

```json
{
  "name": "kairo",
  "version": "0.1.0",
  "private": true,
  "description": "A modern reading platform for manga, manhwa, manhua and webtoons.",
  "scripts": {
    "dev": "next dev",
    "build": "next build",
    "start": "next start",
    "lint": "next lint",
    "typecheck": "tsc --noEmit",
    "db:push": "prisma db push",
    "db:studio": "prisma studio",
    "db:seed": "tsx prisma/seed.ts",
    "postinstall": "prisma generate"
  },
  "dependencies": {
    "@prisma/client": "^5.20.0",
    "clsx": "^2.1.1",
    "lucide-react": "^0.451.0",
    "next": "^14.2.15",
    "next-themes": "^0.3.0",
    "react": "^18.3.1",
    "react-dom": "^18.3.1",
    "tailwind-merge": "^2.5.4",
    "zod": "^3.23.8"
  },
  "devDependencies": {
    "@types/node": "^20.16.11",
    "@types/react": "^18.3.11",
    "@types/react-dom": "^18.3.1",
    "autoprefixer": "^10.4.20",
    "postcss": "^8.4.47",
    "prisma": "^5.20.0",
    "tailwindcss": "^3.4.13",
    "tsx": "^4.19.1",
    "typescript": "^5.6.3"
  },
  "engines": {
    "node": ">=18.17"
  }
}

