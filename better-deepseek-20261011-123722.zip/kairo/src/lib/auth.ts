import "server-only";
import { cookies } from "next/headers";
import {
  SESSION_COOKIE,
  decodeSession,
  encodeSession,
  type SessionPayload,
} from "./session";

/**
 * Demo session layer.
 *
 * Everything in the app reads the current user through `getSession()`.
 * To move to NextAuth v5:
 *
 *   1. npm i next-auth@beta @auth/prisma-adapter
 *   2. Create `src/auth.ts` exporting `handlers`, `auth`, `signIn`, `signOut`.
 *   3. Replace the body of `getSession()` below with:
 *        const session = await auth();
 *        return session?.user ?? null;
 *
 * No other file needs to change.
 */

export type { SessionPayload };

const ONE_WEEK = 60 * 60 * 24 * 7;

export async function getSession(): Promise<SessionPayload | null> {
  const raw = cookies().get(SESSION_COOKIE)?.value;
  return raw ? decodeSession(raw) : null;
}

export async function requireSession(): Promise<SessionPayload> {
  const session = await getSession();
  if (!session) throw new Error("UNAUTHORIZED");
  return session;
}

export function setSessionCookie(payload: SessionPayload) {
  cookies().set(SESSION_COOKIE, encodeSession(payload), {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: ONE_WEEK,
  });
}

export function clearSessionCookie() {
  cookies().set(SESSION_COOKIE, "", { path: "/", maxAge: 0 });
}

/**
 * Demo credential check. Accepts anything with a plausible shape so the app is
 * explorable without a database. `admin@*` grants the ADMIN role.
 */
export function verifyDemoCredentials(email: string, password: string): SessionPayload | null {
  const normalized = email.trim().toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalized)) return null;
  if (password.length < 4) return null;

  const isAdmin = normalized.startsWith("admin@");
  const username = normalized.split("@")[0].replace(/[^a-z0-9_]/g, "") || "reader";

  return {
    id: `demo_${Buffer.from(normalized).toString("hex").slice(0, 12)}`,
    email: normalized,
    username,
    role: isAdmin ? "ADMIN" : "USER",
    avatar: undefined,
  };
}
