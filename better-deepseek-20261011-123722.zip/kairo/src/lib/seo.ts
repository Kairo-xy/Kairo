import type { Series } from "./types";

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000";
const SITE_NAME = "kairo";

export function absoluteUrl(path: string): string {
  return new URL(path, SITE_URL).toString();
}

/** schema.org ComicSeries — Google reads this for rich results. */
export function seriesJsonLd(series: Series) {
  return {
    "@context": "https://schema.org",
    "@type": "ComicSeries",
    name: series.title,
    alternateName: series.altTitles,
    description: series.description,
    image: series.coverUrl,
    url: absoluteUrl(`/series/${series.slug}`),
    author: { "@type": "Person", name: series.author },
    illustrator: { "@type": "Person", name: series.artist },
    genre: series.genres,
    datePublished: String(series.releaseYear),
    aggregateRating: {
      "@type": "AggregateRating",
      ratingValue: series.rating,
      ratingCount: series.ratingCount,
      bestRating: 10,
      worstRating: 0,
    },
    publisher: { "@type": "Organization", name: SITE_NAME },
  };
}

export function websiteJsonLd() {
  return {
    "@context": "https://schema.org",
    "@type": "WebSite",
    name: SITE_NAME,
    url: SITE_URL,
    potentialAction: {
      "@type": "SearchAction",
      target: `${SITE_URL}/search?q={search_term_string}`,
      "query-input": "required name=search_term_string",
    },
  };
}
