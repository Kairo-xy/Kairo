/**
 * Edge-safe session encoding.
 *
 * Split out from `auth.ts` because `middleware.ts` runs on the Edge runtime
 * and must not import anything that pulls in Node APIs.
 *
 * The payload is a plain URL-encoded JSON blob. It is NOT signed and is only
 * suitable for the demo. When you swap in NextAuth, delete this file and
 * replace `middleware.ts` with `export { default } from "next-auth/middleware"`.
 */

export const SESSION_COOKIE = "kairo_session";

export interface SessionPayload {
  id: string;
  email: string;
  username: string;
  avatar?: string;
  role: "USER" | "MODERATOR" | "ADMIN";
}

export function encodeSession(payload: SessionPayload): string {
  return encodeURIComponent(JSON.stringify(payload));
}

export function decodeSession(raw: string): SessionPayload | null {
  try {
    const parsed = JSON.parse(decodeURIComponent(raw)) as SessionPayload;
    if (!parsed?.id || !parsed?.email) return null;
    return parsed;
  } catch {
    return null;
  }
}
