import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

/** Tailwind-aware className merge. */
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

const numberFormat = new Intl.NumberFormat("en", { notation: "compact", maximumFractionDigits: 1 });
const dateFormat = new Intl.DateTimeFormat("en", { year: "numeric", month: "short", day: "numeric" });
const relativeFormat = new Intl.RelativeTimeFormat("en", { numeric: "auto" });

export function formatCompact(n: number): string {
  return numberFormat.format(n);
}

export function formatRating(r: number): string {
  return r.toFixed(1);
}

export function formatDate(input: string | Date): string {
  return dateFormat.format(typeof input === "string" ? new Date(input) : input);
}

/** "3 days ago", "in 2 hours". */
export function formatRelative(input: string | Date): string {
  const date = typeof input === "string" ? new Date(input) : input;
  const diffMs = date.getTime() - Date.now();
  const abs = Math.abs(diffMs);

  const MIN = 60_000;
  const HOUR = 60 * MIN;
  const DAY = 24 * HOUR;
  const WEEK = 7 * DAY;
  const MONTH = 30 * DAY;
  const YEAR = 365 * DAY;

  if (abs < MIN) return "just now";
  if (abs < HOUR) return relativeFormat.format(Math.round(diffMs / MIN), "minute");
  if (abs < DAY) return relativeFormat.format(Math.round(diffMs / HOUR), "hour");
  if (abs < WEEK) return relativeFormat.format(Math.round(diffMs / DAY), "day");
  if (abs < MONTH) return relativeFormat.format(Math.round(diffMs / WEEK), "week");
  if (abs < YEAR) return relativeFormat.format(Math.round(diffMs / MONTH), "month");
  return relativeFormat.format(Math.round(diffMs / YEAR), "year");
}

/** Chapter numbers are floats so 12.5 works. 12 -> "12", 12.5 -> "12.5". */
export function formatChapterNumber(n: number): string {
  return Number.isInteger(n) ? String(n) : n.toFixed(1);
}

export function pluralize(count: number, singular: string, plural = `${singular}s`): string {
  return `${count} ${count === 1 ? singular : plural}`;
}

/** Natural sort: chapter-2.png before chapter-10.png. Used by the admin uploader. */
export function naturalCompare(a: string, b: string): number {
  return a.localeCompare(b, undefined, { numeric: true, sensitivity: "base" });
}

export function truncate(text: string, max: number): string {
  if (text.length <= max) return text;
  return `${text.slice(0, max).trimEnd()}…`;
}

/** Deterministic pseudo-random in [0,1) from a string seed. */
export function seededRandom(seed: string): number {
  let h = 2166136261;
  for (let i = 0; i < seed.length; i++) {
    h ^= seed.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return ((h >>> 0) % 100000) / 100000;
}

export function clamp(value: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, value));
}

export function debounce<T extends (...args: never[]) => void>(fn: T, ms: number) {
  let timer: ReturnType<typeof setTimeout> | undefined;
  return (...args: Parameters<T>) => {
    if (timer) clearTimeout(timer);
    timer = setTimeout(() => fn(...args), ms);
  };
}
