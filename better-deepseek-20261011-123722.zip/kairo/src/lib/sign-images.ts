import "server-only";
import { createHmac, timingSafeEqual } from "node:crypto";

/**
 * Optional image URL signing.
 *
 * Object storage that serves public URLs can be hotlinked forever. Appending a
 * short-lived HMAC turns a page image into a token that expires, which makes
 * scraping meaningfully more expensive without hurting legitimate readers
 * (the CDN caches per-URL, and readers page through quickly).
 *
 * Enable by setting IMAGE_SIGNING_SECRET. When it's unset, URLs pass through
 * untouched so local development stays simple.
 */

const SECRET = process.env.IMAGE_SIGNING_SECRET;
const TTL_SECONDS = 60 * 60 * 6; // long enough to finish a chapter

export function signImageUrl(url: string, now = Math.floor(Date.now() / 1000)): string {
  if (!SECRET) return url;

  const exp = now + TTL_SECONDS;
  const sig = createHmac("sha256", SECRET).update(`${url}:${exp}`).digest("base64url");

  const separator = url.includes("?") ? "&" : "?";
  return `${url}${separator}exp=${exp}&sig=${sig}`;
}

export function verifyImageSignature(
  url: string,
  exp: string | null,
  sig: string | null,
): boolean {
  if (!SECRET) return true;
  if (!exp || !sig) return false;

  const expected = createHmac("sha256", SECRET).update(`${url}:${exp}`).digest("base64url");
  const a = Buffer.from(expected);
  const b = Buffer.from(sig);
  if (a.length !== b.length) return false;
  if (!timingSafeEqual(a, b)) return false;

  return Number(exp) > Math.floor(Date.now() / 1000);
}
