import { z } from "zod";

/**
 * Every route handler validates its input through one of these schemas.
 * Keeping them in a single module means the client and the server can never
 * drift apart — import the same schema in a form and in its handler.
 */

export const seriesStatusSchema = z.enum(["ONGOING", "COMPLETED", "HIATUS", "CANCELLED"]);
export const seriesTypeSchema = z.enum(["MANGA", "MANHWA", "MANHUA", "WEBTOON"]);
export const sortSchema = z.enum(["popular", "latest", "rating", "az", "newest"]);
export const libraryStatusSchema = z.enum([
  "READING",
  "PLAN_TO_READ",
  "COMPLETED",
  "ON_HOLD",
  "DROPPED",
]);

const csv = <T extends z.ZodTypeAny>(inner: T) =>
  z.preprocess(
    (v) => (typeof v === "string" && v.length > 0 ? v.split(",").filter(Boolean) : undefined),
    z.array(inner).optional(),
  );

export const seriesQuerySchema = z.object({
  q: z.string().trim().max(120).optional(),
  genres: csv(z.string().max(40)),
  status: csv(seriesStatusSchema),
  type: csv(seriesTypeSchema),
  year: z.coerce.number().int().min(1950).max(2100).optional(),
  minRating: z.coerce.number().min(0).max(10).optional(),
  sort: sortSchema.default("popular"),
  page: z.coerce.number().int().min(1).max(500).default(1),
  limit: z.coerce.number().int().min(1).max(48).default(24),
});

export const searchQuerySchema = z.object({
  q: z.string().trim().min(1).max(120),
  limit: z.coerce.number().int().min(1).max(20).default(8),
});

export const progressSchema = z.object({
  seriesId: z.string().min(1).max(64),
  chapterId: z.string().min(1).max(64),
  page: z.number().int().min(0).max(10_000),
});

export const librarySchema = z.object({
  seriesId: z.string().min(1).max(64),
  status: libraryStatusSchema,
});

export const commentSchema = z.object({
  chapterId: z.string().min(1).max(64),
  body: z.string().trim().min(1).max(4000),
  parentId: z.string().min(1).max(64).nullable().optional(),
  spoiler: z.boolean().optional().default(false),
});

export const loginSchema = z.object({
  email: z.string().trim().email().max(200),
  password: z.string().min(4).max(200),
});

export const registerSchema = z.object({
  email: z.string().trim().email().max(200),
  username: z
    .string()
    .trim()
    .min(3)
    .max(24)
    .regex(/^[a-zA-Z0-9_]+$/, "Letters, numbers and underscores only"),
  password: z.string().min(8).max(200),
});

export const adminChapterSchema = z.object({
  seriesId: z.string().min(1).max(64),
  number: z.number().positive(),
  title: z.string().trim().max(160).optional(),
  pageKeys: z.array(z.string().min(1)).min(1).max(500),
});

export type SeriesQueryInput = z.infer<typeof seriesQuerySchema>;
export type ProgressInput = z.infer<typeof progressSchema>;
export type LibraryInput = z.infer<typeof librarySchema>;
export type CommentInput = z.infer<typeof commentSchema>;
