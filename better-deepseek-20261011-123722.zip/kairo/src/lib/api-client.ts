"use client";

import type {
  ChapterDetail,
  Comment,
  LibraryStatus,
  Paginated,
  Series,
  SeriesDetail,
  SeriesQuery,
} from "./types";

/** Serialise a query object into a stable query string (skips empties). */
export function toQueryString(query: Record<string, unknown>): string {
  const sp = new URLSearchParams();
  for (const [key, value] of Object.entries(query)) {
    if (value === undefined || value === null || value === "") continue;
    if (Array.isArray(value)) {
      if (!value.length) continue;
      sp.set(key, value.join(","));
    } else {
      sp.set(key, String(value));
    }
  }
  const s = sp.toString();
  return s ? `?${s}` : "";
}

async function request<T>(url: string, init?: RequestInit): Promise<T> {
  const res = await fetch(url, {
    ...init,
    headers: { "Content-Type": "application/json", ...(init?.headers ?? {}) },
  });
  if (!res.ok) {
    const message = await res.text().catch(() => res.statusText);
    throw new Error(message || `Request failed: ${res.status}`);
  }
  return (await res.json()) as T;
}

export const api = {
  series(query: SeriesQuery = {}): Promise<Paginated<Series>> {
    return request(`/api/series${toQueryString(query as Record<string, unknown>)}`);
  },

  seriesDetail(slug: string): Promise<SeriesDetail> {
    return request(`/api/series/${encodeURIComponent(slug)}`);
  },

  chapter(id: string): Promise<ChapterDetail> {
    return request(`/api/chapters/${encodeURIComponent(id)}`);
  },

  search(q: string, limit = 8): Promise<{ items: Series[] }> {
    return request(`/api/search${toQueryString({ q, limit })}`);
  },

  saveProgress(input: { seriesId: string; chapterId: string; page: number }) {
    return request<{ ok: true }>(`/api/progress`, {
      method: "POST",
      body: JSON.stringify(input),
    });
  },

  listProgress() {
    return request<{ items: unknown[] }>(`/api/progress`);
  },

  setLibrary(seriesId: string, status: LibraryStatus) {
    return request<{ ok: true }>(`/api/library`, {
      method: "POST",
      body: JSON.stringify({ seriesId, status }),
    });
  },

  removeLibrary(seriesId: string) {
    return request<{ ok: true }>(`/api/library${toQueryString({ seriesId })}`, {
      method: "DELETE",
    });
  },

  listLibrary() {
    return request<{ items: unknown[] }>(`/api/library`);
  },

  comments(chapterId: string) {
    return request<{ items: Comment[] }>(
      `/api/comments${toQueryString({ chapterId })}`,
    );
  },

  postComment(input: {
    chapterId: string;
    body: string;
    parentId?: string | null;
    spoiler?: boolean;
  }) {
    return request<{ item: Comment }>(`/api/comments`, {
      method: "POST",
      body: JSON.stringify(input),
    });
  },
};
