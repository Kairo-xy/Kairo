/**
 * Domain types for kairo.
 *
 * These intentionally mirror the Prisma models in `prisma/schema.prisma`
 * so that swapping the mock data layer for real queries is a no-op for
 * every consumer in `src/components` and `src/app`.
 */

export type Role = "USER" | "MODERATOR" | "ADMIN";

export type SeriesType = "MANGA" | "MANHWA" | "MANHUA" | "WEBTOON";

export type SeriesStatus = "ONGOING" | "COMPLETED" | "HIATUS" | "CANCELLED";

export type LibraryStatus =
  | "READING"
  | "PLAN_TO_READ"
  | "COMPLETED"
  | "ON_HOLD"
  | "DROPPED";

export type SortKey = "popular" | "latest" | "rating" | "az" | "newest";

export interface Genre {
  id: string;
  name: string;
  slug: string;
}

export interface Series {
  id: string;
  slug: string;
  title: string;
  altTitles: string[];
  description: string;
  coverUrl: string;
  bannerUrl: string;
  author: string;
  artist: string;
  type: SeriesType;
  status: SeriesStatus;
  releaseYear: number;
  /** 0–10 */
  rating: number;
  ratingCount: number;
  views: number;
  /** Genre slugs. */
  genres: string[];
  chapterCount: number;
  latestChapter: number;
  latestChapterAt: string;
  featured?: boolean;
}

export interface Chapter {
  id: string;
  seriesId: string;
  seriesSlug: string;
  number: number;
  title: string;
  publishedAt: string;
  pageCount: number;
  isLocked: boolean;
}

export interface Page {
  id: string;
  chapterId: string;
  index: number;
  imageUrl: string;
  width: number;
  height: number;
}

export interface SeriesDetail extends Series {
  chapters: Chapter[];
  related: Series[];
}

export interface ChapterDetail {
  chapter: Chapter;
  series: Series;
  pages: Page[];
  prev: Chapter | null;
  next: Chapter | null;
}

export interface SeriesQuery {
  q?: string;
  genres?: string[];
  status?: SeriesStatus[];
  type?: SeriesType[];
  year?: number;
  minRating?: number;
  sort?: SortKey;
  page?: number;
  limit?: number;
}

export interface Paginated<T> {
  items: T[];
  total: number;
  page: number;
  pages: number;
}

export interface SessionUser {
  id: string;
  email: string;
  username: string;
  avatar?: string;
  role: Role;
}

export interface ReadingProgressEntry {
  seriesId: string;
  seriesSlug: string;
  seriesTitle: string;
  coverUrl: string;
  chapterId: string;
  chapterNumber: number;
  page: number;
  totalPages: number;
  updatedAt: string;
}

export interface LibraryEntry {
  seriesId: string;
  seriesSlug: string;
  status: LibraryStatus;
  updatedAt: string;
}

export interface Comment {
  id: string;
  chapterId: string;
  userId: string;
  username: string;
  avatar?: string;
  body: string;
  spoiler: boolean;
  parentId: string | null;
  createdAt: string;
  replies?: Comment[];
}

/** Reader preferences — persisted to localStorage under `kairo:reader`. */
export type ReaderMode = "single" | "double" | "strip";
export type ReaderFit = "width" | "height" | "original";
export type ReaderBackground = "black" | "gray" | "white";
export type ReaderDirection = "ltr" | "rtl";

export interface ReaderSettings {
  mode: ReaderMode;
  fit: ReaderFit;
  gap: number;
  background: ReaderBackground;
  brightness: number;
  direction: ReaderDirection;
  quality: "low" | "medium" | "high";
  autoHideToolbar: boolean;
}

export const DEFAULT_READER_SETTINGS: ReaderSettings = {
  mode: "single",
  fit: "height",
  gap: 0,
  background: "black",
  brightness: 100,
  direction: "ltr",
  quality: "high",
  autoHideToolbar: true,
};
