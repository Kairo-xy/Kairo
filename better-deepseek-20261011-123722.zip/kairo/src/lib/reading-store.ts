"use client";

/**
 * Guest reading state.
 *
 * Signed-in users get server-side sync via `/api/progress`. Guests get this:
 * a small localStorage store that mirrors the same shape, so the UI never has
 * to branch on auth state — it just reads from one place.
 */

import type { LibraryStatus, ReadingProgressEntry } from "./types";

const PROGRESS_KEY = "kairo:progress";
const LIBRARY_KEY = "kairo:library";
const READ_KEY = "kairo:read-chapters";

function read<T>(key: string, fallback: T): T {
  if (typeof window === "undefined") return fallback;
  try {
    const raw = window.localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

function write(key: string, value: unknown) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(key, JSON.stringify(value));
    window.dispatchEvent(new Event("kairo:store"));
  } catch {
    /* quota exceeded — not worth interrupting the reader for */
  }
}

// ─── Progress ────────────────────────────────────────────────────────────────

export function getProgressMap(): Record<string, ReadingProgressEntry> {
  return read<Record<string, ReadingProgressEntry>>(PROGRESS_KEY, {});
}

export function getProgress(seriesId: string): ReadingProgressEntry | null {
  return getProgressMap()[seriesId] ?? null;
}

export function saveProgress(entry: ReadingProgressEntry) {
  const map = getProgressMap();
  map[entry.seriesId] = { ...entry, updatedAt: new Date().toISOString() };
  write(PROGRESS_KEY, map);
}

export function getContinueReading(limit = 18): ReadingProgressEntry[] {
  return Object.values(getProgressMap())
    .sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime())
    .slice(0, limit);
}

// ─── Read markers ────────────────────────────────────────────────────────────

export function getReadChapters(): Record<string, true> {
  return read<Record<string, true>>(READ_KEY, {});
}

export function markChapterRead(chapterId: string) {
  const map = getReadChapters();
  map[chapterId] = true;
  write(READ_KEY, map);
}

export function isChapterRead(chapterId: string): boolean {
  return Boolean(getReadChapters()[chapterId]);
}

// ─── Library ─────────────────────────────────────────────────────────────────

export type GuestLibrary = Record<string, { status: LibraryStatus; updatedAt: string }>;

export function getGuestLibrary(): GuestLibrary {
  return read<GuestLibrary>(LIBRARY_KEY, {});
}

export function setGuestLibraryStatus(seriesId: string, status: LibraryStatus) {
  const map = getGuestLibrary();
  map[seriesId] = { status, updatedAt: new Date().toISOString() };
  write(LIBRARY_KEY, map);
}

export function removeGuestLibraryEntry(seriesId: string) {
  const map = getGuestLibrary();
  delete map[seriesId];
  write(LIBRARY_KEY, map);
}

export function getGuestLibraryStatus(seriesId: string): LibraryStatus | null {
  return getGuestLibrary()[seriesId]?.status ?? null;
}
