import { PrismaClient } from "@prisma/client";

/**
 * Prisma singleton.
 *
 * Only imported by the seed script and by API routes once you migrate off the
 * mock data layer. Next.js hot-reloads modules in dev, which would otherwise
 * open a new connection pool on every edit — hence the global cache.
 */
const globalForPrisma = globalThis as unknown as { prisma?: PrismaClient };

export const prisma =
  globalForPrisma.prisma ??
  new PrismaClient({
    log: process.env.NODE_ENV === "development" ? ["warn", "error"] : ["error"],
  });

if (process.env.NODE_ENV !== "production") {
  globalForPrisma.prisma = prisma;
}
