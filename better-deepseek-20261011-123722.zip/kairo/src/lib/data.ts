/**
 * ─────────────────────────────────────────────────────────────────────────────
 * MOCK DATA LAYER
 * ─────────────────────────────────────────────────────────────────────────────
 *
 * The entire catalog is generated deterministically from a seed so that the UI
 * is stable across reloads (no flickering covers, no reshuffled rails) and so
 * the app runs with zero infrastructure.
 *
 * ## Replacing this with Prisma
 *
 * Every exported function below is the exact contract the UI consumes. Swap the
 * bodies for `prisma.*` calls and nothing else in the codebase changes. See the
 * README section "Going to production" for a worked example.
 */

import type {
  Chapter,
  Genre,
  Page,
  Paginated,
  Series,
  SeriesDetail,
  SeriesQuery,
  SeriesStatus,
  SeriesType,
  ChapterDetail,
} from "./types";

// ─────────────────────────────────────────────────────────────────────────────
// Reference data
// ─────────────────────────────────────────────────────────────────────────────

export const GENRES: Genre[] = [
  { id: "g_action", name: "Action", slug: "action" },
  { id: "g_adventure", name: "Adventure", slug: "adventure" },
  { id: "g_comedy", name: "Comedy", slug: "comedy" },
  { id: "g_drama", name: "Drama", slug: "drama" },
  { id: "g_fantasy", name: "Fantasy", slug: "fantasy" },
  { id: "g_horror", name: "Horror", slug: "horror" },
  { id: "g_isekai", name: "Isekai", slug: "isekai" },
  { id: "g_martial-arts", name: "Martial Arts", slug: "martial-arts" },
  { id: "g_mystery", name: "Mystery", slug: "mystery" },
  { id: "g_psychological", name: "Psychological", slug: "psychological" },
  { id: "g_romance", name: "Romance", slug: "romance" },
  { id: "g_sci-fi", name: "Sci-Fi", slug: "sci-fi" },
  { id: "g_slice-of-life", name: "Slice of Life", slug: "slice-of-life" },
  { id: "g_sports", name: "Sports", slug: "sports" },
  { id: "g_supernatural", name: "Supernatural", slug: "supernatural" },
  { id: "g_thriller", name: "Thriller", slug: "thriller" },
];

export const GENRE_NAME: Record<string, string> = Object.fromEntries(
  GENRES.map((g) => [g.slug, g.name]),
);

export const SERIES_TYPES: SeriesType[] = ["MANGA", "MANHWA", "MANHUA", "WEBTOON"];
export const SERIES_STATUSES: SeriesStatus[] = ["ONGOING", "COMPLETED", "HIATUS", "CANCELLED"];

// ─────────────────────────────────────────────────────────────────────────────
// Deterministic generation
// ─────────────────────────────────────────────────────────────────────────────

const TITLE_A = [
  "Shadow", "Crimson", "Silent", "Eternal", "Broken", "Golden", "Iron", "Hollow",
  "Scarlet", "Midnight", "Frozen", "Savage", "Gentle", "Last", "Lost", "Neon",
  "Ashen", "Verdant", "Static", "Solar", "Pale", "Distant", "Bitter", "Radiant",
];

const TITLE_B = [
  "Blade", "Garden", "Archive", "Circuit", "Requiem", "Ledger", "Symphony",
  "Harbor", "Covenant", "Lullaby", "Paradox", "Vagabond", "Alchemy", "Oracle",
  "Tide", "Ember", "Cipher", "Monolith", "Sonata", "Drift", "Lantern", "Atlas",
  "Sermon", "Fracture",
];

const AUTHORS = [
  "Rei Katsuragi", "Min-seo Han", "Alvaro Bianchi", "Nadia Okonkwo", "Yuki Tachibana",
  "Farah El-Amin", "Tomas Lindqvist", "Jun-ho Park", "Iris Vandermeer", "Kenji Aoyama",
  "Lucia Ferrer", "Dmitri Volkov", "Amara Nwosu", "Sora Ishikawa", "Elias Brandt",
];

const ARTISTS = [
  "Studio Kagami", "Hoshino Works", "PXL Atelier", "Nine Lanterns", "Redline Ink",
  "Moonlit Draw", "Paper Ghost", "Studio Vermilion", "Inkwell Collective", "Nova Pen",
];

const SYNOPSIS_OPENERS = [
  "After a decade of quiet, the city starts remembering things it shouldn't.",
  "There is a debt that must be paid in memories, and she has almost none left.",
  "The last cartographer of a drowned continent is hired to map a country that does not exist.",
  "Every night at 3:14 AM, the same train arrives at a station that was demolished in 1987.",
  "He can hear the thoughts of anyone who has lied to him. Everyone lies.",
  "The tournament has no rules, no spectators, and no survivors — until this year.",
  "A courier discovers that the packages she delivers are pieces of a single person.",
  "When the sun stopped moving, the world learned to live in permanent dusk.",
  "Two rival alchemists are forced to share one body for the length of a season.",
  "The garden grows only what has been forgotten. It is getting very crowded.",
];

const SYNOPSIS_BODIES = [
  "What begins as a favour spirals into a decade-long unraveling of everything the protagonist believed about their family, their city, and the small, ordinary mercy of being forgotten.",
  "Told across three timelines, the story refuses to hand out easy answers — every revelation costs someone something they cannot get back.",
  "A slow-burn character study wrapped in genre clothing, it earns its action by making you care about who is left standing afterwards.",
  "The art carries the weight here: wide, patient panels that let silence do the work that dialogue cannot.",
  "Sharp, funny, and quietly devastating. It understands that the most frightening thing in the world is someone who is completely certain.",
  "A story about labour, loyalty, and the specific loneliness of being very good at something nobody values.",
  "It builds its world through small details — a vending machine that only stocks one drink, a bus route that skips a single stop — until the strangeness feels like home.",
  "Brutal, tender, and structurally inventive, it keeps finding new ways to ask the same unanswerable question.",
];

function mulberry32(seed: number) {
  let a = seed;
  return function next() {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function pick<T>(rand: () => number, arr: readonly T[]): T {
  return arr[Math.floor(rand() * arr.length)];
}

function pickMany<T>(rand: () => number, arr: readonly T[], count: number): T[] {
  const pool = [...arr];
  const out: T[] = [];
  for (let i = 0; i < count && pool.length; i++) {
    out.push(pool.splice(Math.floor(rand() * pool.length), 1)[0]);
  }
  return out;
}

function slugify(input: string): string {
  return input
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
}

const TOTAL_SERIES = 48;

function buildCatalog(): Series[] {
  const rand = mulberry32(20260211);
  const out: Series[] = [];
  const usedSlugs = new Set<string>();

  for (let i = 0; i < TOTAL_SERIES; i++) {
    const title = `${TITLE_A[i % TITLE_A.length]} ${TITLE_B[(i * 7) % TITLE_B.length]}`;

    let slug = slugify(title);
    let n = 2;
    while (usedSlugs.has(slug)) slug = `${slugify(title)}-${n++}`;
    usedSlugs.add(slug);

    const type = pick(rand, SERIES_TYPES);
    const status = (() => {
      const roll = rand();
      if (roll < 0.62) return "ONGOING" as const;
      if (roll < 0.86) return "COMPLETED" as const;
      if (roll < 0.95) return "HIATUS" as const;
      return "CANCELLED" as const;
    })();

    const chapterCount = status === "COMPLETED"
      ? 40 + Math.floor(rand() * 160)
      : 4 + Math.floor(rand() * 90);

    const releaseYear = 2009 + Math.floor(rand() * 17);
    const rating = Number((6.2 + rand() * 3.7).toFixed(1));
    const ratingCount = 180 + Math.floor(rand() * 48_000);
    const views = 12_000 + Math.floor(rand() * 40_000_000);
    const daysSinceLast = Math.floor(rand() * 260);

    const latestChapterAt = new Date(Date.now() - daysSinceLast * 86_400_000).toISOString();

    const altTitlePool = [
      `${title} (Official)`,
      `${TITLE_B[(i * 3) % TITLE_B.length]} no ${TITLE_A[(i * 5) % TITLE_A.length]}`,
      `${title}: Rebirth`,
    ];

    out.push({
      id: `s_${String(i + 1).padStart(3, "0")}`,
      slug,
      title,
      altTitles: altTitlePool.slice(0, 1 + Math.floor(rand() * 2)),
      description: `${pick(rand, SYNOPSIS_OPENERS)} ${pick(rand, SYNOPSIS_BODIES)}`,
      coverUrl: `https://picsum.photos/seed/kairo-cover-${slug}/400/600`,
      bannerUrl: `https://picsum.photos/seed/kairo-banner-${slug}/1600/600`,
      author: pick(rand, AUTHORS),
      artist: pick(rand, ARTISTS),
      type,
      status,
      releaseYear,
      rating,
      ratingCount,
      views,
      genres: pickMany(rand, GENRES, 2 + Math.floor(rand() * 3)).map((g) => g.slug),
      chapterCount,
      latestChapter: chapterCount,
      latestChapterAt,
      featured: i < 6,
    });
  }

  return out;
}

export const ALL_SERIES: Series[] = buildCatalog();

const SERIES_BY_ID = new Map(ALL_SERIES.map((s) => [s.id, s]));
const SERIES_BY_SLUG = new Map(ALL_SERIES.map((s) => [s.slug, s]));

// ─────────────────────────────────────────────────────────────────────────────
// Chapters & pages (generated lazily, cached in-process)
// ─────────────────────────────────────────────────────────────────────────────

const chapterCache = new Map<string, Chapter[]>();

export function getChaptersForSeries(seriesId: string): Chapter[] {
  const cached = chapterCache.get(seriesId);
  if (cached) return cached;

  const series = SERIES_BY_ID.get(seriesId);
  if (!series) return [];

  const rand = mulberry32(
    seriesId.split("").reduce((acc, c) => acc + c.charCodeAt(0), 7919),
  );

  const chapters: Chapter[] = [];
  const newest = new Date(series.latestChapterAt).getTime();

  for (let n = series.chapterCount; n >= 1; n--) {
    const age = series.chapterCount - n;
    // Newest chapter is `latestChapterAt`; older ones step back ~4 days each.
    const publishedAt = new Date(newest - age * 3.6 * 86_400_000).toISOString();
    const roll = rand();

    chapters.push({
      id: `${seriesId}-c${n}`,
      seriesId,
      seriesSlug: series.slug,
      number: n,
      title:
        roll < 0.45
          ? `Chapter ${n}`
          : roll < 0.75
            ? pick(rand, TITLE_B) + " " + pick(rand, ["Rising", "Falling", "Quiet", "Burning", "Returning"])
            : pick(rand, [
                "The Long Way Down",
                "Everything We Kept",
                "A Small, Honest Thing",
                "What the Tide Left",
                "No One Is Coming",
                "The Second Door",
                "Salt and Rust",
                "Homecoming",
              ]),
      publishedAt,
      pageCount: 14 + Math.floor(rand() * 30),
      isLocked: false,
    });
  }

  chapterCache.set(seriesId, chapters);
  return chapters;
}

const pageCache = new Map<string, Page[]>();

function getPagesForChapter(chapterId: string): Page[] {
  const cached = pageCache.get(chapterId);
  if (cached) return cached;

  const chapter = findChapterById(chapterId);
  if (!chapter) return [];

  const pages: Page[] = Array.from({ length: chapter.pageCount }, (_, i) => ({
    id: `${chapterId}-p${i}`,
    chapterId,
    index: i,
    imageUrl: `https://picsum.photos/seed/${chapterId}-${i}/800/1200`,
    width: 800,
    height: 1200,
  }));

  pageCache.set(chapterId, pages);
  return pages;
}

function findChapterById(chapterId: string): Chapter | null {
  const seriesId = chapterId.split("-c")[0];
  return getChaptersForSeries(seriesId).find((c) => c.id === chapterId) ?? null;
}

// ─────────────────────────────────────────────────────────────────────────────
// Public queries — the contract to reimplement with Prisma
// ─────────────────────────────────────────────────────────────────────────────

export async function querySeries(query: SeriesQuery): Promise<Paginated<Series>> {
  const {
    q,
    genres,
    status,
    type,
    year,
    minRating,
    sort = "popular",
    page = 1,
    limit = 24,
  } = query;

  let items = ALL_SERIES.slice();

  if (q) {
    const needle = q.trim().toLowerCase();
    items = items.filter((s) => {
      const haystack = [
        s.title,
        ...s.altTitles,
        s.author,
        s.artist,
        ...s.genres.map((g) => GENRE_NAME[g] ?? g),
      ]
        .join(" ")
        .toLowerCase();
      return haystack.includes(needle);
    });
  }

  if (genres?.length) {
    items = items.filter((s) => genres.every((g) => s.genres.includes(g)));
  }
  if (status?.length) {
    items = items.filter((s) => status.includes(s.status));
  }
  if (type?.length) {
    items = items.filter((s) => type.includes(s.type));
  }
  if (year) {
    items = items.filter((s) => s.releaseYear === year);
  }
  if (typeof minRating === "number") {
    items = items.filter((s) => s.rating >= minRating);
  }

  switch (sort) {
    case "popular":
      items.sort((a, b) => b.views - a.views);
      break;
    case "latest":
      items.sort(
        (a, b) => new Date(b.latestChapterAt).getTime() - new Date(a.latestChapterAt).getTime(),
      );
      break;
    case "rating":
      items.sort((a, b) => b.rating - a.rating || b.ratingCount - a.ratingCount);
      break;
    case "newest":
      items.sort((a, b) => b.releaseYear - a.releaseYear);
      break;
    case "az":
      items.sort((a, b) => a.title.localeCompare(b.title));
      break;
  }

  const total = items.length;
  const pages = Math.max(1, Math.ceil(total / limit));
  const safePage = Math.min(Math.max(1, page), pages);

  return {
    items: items.slice((safePage - 1) * limit, safePage * limit),
    total,
    page: safePage,
    pages,
  };
}

export async function getSeriesBySlug(slug: string): Promise<SeriesDetail | null> {
  const series = SERIES_BY_SLUG.get(slug);
  if (!series) return null;

  return {
    ...series,
    chapters: getChaptersForSeries(series.id),
    related: await getRelated(series, 12),
  };
}

export async function getChapterDetail(chapterId: string): Promise<ChapterDetail | null> {
  const chapter = findChapterById(chapterId);
  if (!chapter) return null;

  const series = SERIES_BY_ID.get(chapter.seriesId);
  if (!series) return null;

  const all = getChaptersForSeries(series.id);
  const idx = all.findIndex((c) => c.id === chapter.id);

  return {
    chapter,
    series,
    pages: getPagesForChapter(chapter.id),
    // `all` is newest-first, so "next" is the earlier index.
    prev: idx < all.length - 1 ? all[idx + 1] : null,
    next: idx > 0 ? all[idx - 1] : null,
  };
}

export async function getRelated(series: Series, limit = 12): Promise<Series[]> {
  return ALL_SERIES.filter((s) => s.id !== series.id)
    .map((s) => {
      const overlap = s.genres.filter((g) => series.genres.includes(g)).length;
      return { s, score: overlap * 10 + s.rating - Math.abs(s.releaseYear - series.releaseYear) * 0.1 };
    })
    .sort((a, b) => b.score - a.score)
    .slice(0, limit)
    .map((x) => x.s);
}

export async function searchSeries(q: string, limit = 8): Promise<Series[]> {
  if (!q.trim()) return [];
  const { items } = await querySeries({ q, sort: "popular", limit, page: 1 });
  return items;
}

/** Rails for the home page. */
export async function getHomeRails() {
  const [trending, recentlyUpdated, newReleases, topRated] = await Promise.all([
    querySeries({ sort: "popular", limit: 18 }),
    querySeries({ sort: "latest", limit: 18 }),
    querySeries({ sort: "newest", limit: 18 }),
    querySeries({ sort: "rating", limit: 18 }),
  ]);

  return {
    hero: ALL_SERIES.filter((s) => s.featured).slice(0, 5),
    trending: trending.items,
    recentlyUpdated: recentlyUpdated.items,
    newReleases: newReleases.items,
    topRated: topRated.items,
  };
}

export async function getSeriesById(id: string): Promise<Series | null> {
  return SERIES_BY_ID.get(id) ?? null;
}

export async function getSeriesByIds(ids: string[]): Promise<Series[]> {
  return ids.map((id) => SERIES_BY_ID.get(id)).filter((s): s is Series => Boolean(s));
}

export async function getAvailableYears(): Promise<number[]> {
  const years = new Set(ALL_SERIES.map((s) => s.releaseYear));
  return [...years].sort((a, b) => b - a);
}
