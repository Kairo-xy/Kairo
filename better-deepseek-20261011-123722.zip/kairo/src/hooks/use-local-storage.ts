"use client";

import { useCallback, useEffect, useState } from "react";

/**
 * SSR-safe localStorage state.
 *
 * Returns the default on the server and during the first client render, then
 * hydrates in an effect. This keeps server and client markup identical (no
 * hydration mismatch) at the cost of one extra render — worth it.
 */
export function useLocalStorage<T>(key: string, initialValue: T) {
  const [value, setValue] = useState<T>(initialValue);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(key);
      if (raw !== null) setValue(JSON.parse(raw) as T);
    } catch {
      /* corrupt entry — keep the default */
    }
    setHydrated(true);
  }, [key]);

  useEffect(() => {
    if (!hydrated) return;
    try {
      window.localStorage.setItem(key, JSON.stringify(value));
    } catch {
      /* quota exceeded */
    }
  }, [key, value, hydrated]);

  const reset = useCallback(() => setValue(initialValue), [initialValue]);

  return [value, setValue, hydrated, reset] as const;
}
