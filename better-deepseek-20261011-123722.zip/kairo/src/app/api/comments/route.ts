import { NextResponse, type NextRequest } from "next/server";
import { getSession } from "@/lib/auth";
import { commentSchema } from "@/lib/validation";
import { clientKey, rateLimit } from "@/lib/rate-limit";
import type { Comment } from "@/lib/types";

/** Chapter comments with one level of replies and spoiler tags. */

const memory: Comment[] = [];

export async function GET(req: NextRequest) {
  const chapterId = req.nextUrl.searchParams.get("chapterId");
  if (!chapterId) {
    return NextResponse.json({ error: "chapterId is required" }, { status: 400 });
  }

  const roots = memory.filter((c) => c.chapterId === chapterId && !c.parentId);

  const withReplies = roots.map((root) => ({
    ...root,
    replies: memory.filter((c) => c.parentId === root.id),
  }));

  return NextResponse.json({ items: withReplies });
}

export async function POST(req: NextRequest) {
  const session = await getSession();
  if (!session) {
    return NextResponse.json({ error: "Sign in to comment" }, { status: 401 });
  }

  // Comments are the classic abuse vector — keep the bucket tight.
  const limit = rateLimit(clientKey(req, "comment"), 5, 60_000);
  if (!limit.ok) {
    return NextResponse.json(
      { error: "You're commenting too quickly. Take a breath." },
      { status: 429 },
    );
  }

  const parsed = commentSchema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Invalid comment", issues: parsed.error.flatten().fieldErrors },
      { status: 400 },
    );
  }

  const comment: Comment = {
    id: `c_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`,
    chapterId: parsed.data.chapterId,
    userId: session.id,
    username: session.username,
    avatar: session.avatar,
    body: parsed.data.body,
    spoiler: parsed.data.spoiler ?? false,
    parentId: parsed.data.parentId ?? null,
    createdAt: new Date().toISOString(),
  };

  memory.push(comment);

  /*
  const created = await prisma.comment.create({
    data: {
      userId: session.id,
      chapterId: parsed.data.chapterId,
      parentId: parsed.data.parentId ?? null,
      body: parsed.data.body,
      spoiler: parsed.data.spoiler ?? false,
    },
  });
  */

  return NextResponse.json({ item: comment }, { status: 201 });
}
