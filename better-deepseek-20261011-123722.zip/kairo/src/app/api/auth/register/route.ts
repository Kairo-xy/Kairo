import { NextResponse, type NextRequest } from "next/server";
import { setSessionCookie, verifyDemoCredentials } from "@/lib/auth";
import { registerSchema } from "@/lib/validation";
import { clientKey, rateLimit } from "@/lib/rate-limit";

/** POST /api/auth/register — creates a session (and, in production, a user row). */
export async function POST(req: NextRequest) {
  const limit = rateLimit(clientKey(req, "register"), 5, 60_000);
  if (!limit.ok) {
    return NextResponse.json({ error: "Too many attempts. Try again shortly." }, { status: 429 });
  }

  const parsed = registerSchema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) {
    const first = Object.values(parsed.error.flatten().fieldErrors).flat()[0];
    return NextResponse.json({ error: first ?? "Check your details and try again." }, { status: 400 });
  }

  /*
  const existing = await prisma.user.findFirst({
    where: { OR: [{ email }, { username }] },
    select: { email: true, username: true },
  });
  if (existing) {
    return NextResponse.json({ error: "That email or username is taken." }, { status: 409 });
  }

  const user = await prisma.user.create({
    data: { email, username, passwordHash: await hash(password) },
  });
  */

  const session = verifyDemoCredentials(parsed.data.email, parsed.data.password);
  if (!session) {
    return NextResponse.json({ error: "Could not create the account." }, { status: 400 });
  }

  setSessionCookie({ ...session, username: parsed.data.username });
  return NextResponse.json({ user: { ...session, username: parsed.data.username } }, { status: 201 });
}
