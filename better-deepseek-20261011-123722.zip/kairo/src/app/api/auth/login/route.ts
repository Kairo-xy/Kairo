import { NextResponse, type NextRequest } from "next/server";
import { setSessionCookie, verifyDemoCredentials } from "@/lib/auth";
import { loginSchema } from "@/lib/validation";
import { clientKey, rateLimit } from "@/lib/rate-limit";

/** POST /api/auth/login — demo credential sign-in. */
export async function POST(req: NextRequest) {
  // Credential stuffing is the one place a tight limit genuinely matters.
  const limit = rateLimit(clientKey(req, "login"), 10, 60_000);
  if (!limit.ok) {
    return NextResponse.json(
      { error: "Too many attempts. Try again in a minute." },
      { status: 429 },
    );
  }

  const parsed = loginSchema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json({ error: "Enter a valid email and password." }, { status: 400 });
  }

  const session = verifyDemoCredentials(parsed.data.email, parsed.data.password);
  if (!session) {
    // Deliberately vague — never confirm whether an email exists.
    return NextResponse.json({ error: "Incorrect email or password." }, { status: 401 });
  }

  setSessionCookie(session);
  return NextResponse.json({ user: session });
}
