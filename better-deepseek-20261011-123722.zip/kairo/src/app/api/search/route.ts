import { NextResponse, type NextRequest } from "next/server";
import { searchSeries } from "@/lib/data";
import { searchQuerySchema } from "@/lib/validation";
import { clientKey, rateLimit } from "@/lib/rate-limit";

export const dynamic = "force-dynamic";

/** GET /api/search?q=&limit= — lightweight autocomplete payload. */
export async function GET(req: NextRequest) {
  // Autocomplete fires on every keystroke; give it a more generous bucket than
  // the list endpoints but still bound it.
  const limit = rateLimit(clientKey(req, "search"), 240);
  if (!limit.ok) {
    return NextResponse.json({ error: "Too many requests" }, { status: 429 });
  }

  const parsed = searchQuerySchema.safeParse({
    q: req.nextUrl.searchParams.get("q") ?? "",
    limit: req.nextUrl.searchParams.get("limit") ?? undefined,
  });

  if (!parsed.success) {
    return NextResponse.json({ items: [] });
  }

  const items = await searchSeries(parsed.data.q, parsed.data.limit);

  return NextResponse.json(
    { items },
    { headers: { "Cache-Control": "public, s-maxage=30, stale-while-revalidate=120" } },
  );
}
