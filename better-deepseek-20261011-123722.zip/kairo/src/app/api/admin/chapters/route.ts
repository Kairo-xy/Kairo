import { NextResponse, type NextRequest } from "next/server";
import { getSession } from "@/lib/auth";
import { adminChapterSchema } from "@/lib/validation";

/**
 * POST /api/admin/chapters — publish a chapter.
 *
 * The real implementation should:
 *   1. Validate the caller is an ADMIN (done).
 *   2. Ask the client to PUT each page to a presigned S3/R2 URL.
 *   3. HEAD every object to confirm the upload landed and read its real
 *      dimensions — never trust client-supplied width/height.
 *   4. Write Chapter + Page rows inside a single transaction so a half-uploaded
 *      chapter is never visible to readers.
 *   5. Invalidate the series' cache tag.
 *
 * This stub acknowledges the payload so the admin UI is fully exercisable.
 */
export async function POST(req: NextRequest) {
  const session = await getSession();

  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  if (session.role !== "ADMIN") {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const parsed = adminChapterSchema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Invalid payload", issues: parsed.error.flatten().fieldErrors },
      { status: 400 },
    );
  }

  const { seriesId, number, title, pageKeys } = parsed.data;

  /*
  const chapter = await prisma.$transaction(async (tx) => {
    const created = await tx.chapter.create({
      data: { seriesId, number, title, pageCount: pageKeys.length },
    });
    await tx.page.createMany({
      data: pageKeys.map((key, index) => ({
        chapterId: created.id,
        index,
        imageUrl: `${process.env.CDN_BASE_URL}/${key}`,
        width: 0,  // backfilled by the object-storage HEAD pass
        height: 0,
      })),
    });
    return created;
  });

  revalidateTag(`series:${seriesId}`);
  */

  return NextResponse.json(
    {
      ok: true,
      chapter: {
        id: `pending_${Date.now().toString(36)}`,
        seriesId,
        number,
        title: title ?? `Chapter ${number}`,
        pageCount: pageKeys.length,
      },
    },
    { status: 201 },
  );
}
