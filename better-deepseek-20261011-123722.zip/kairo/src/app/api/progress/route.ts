import { NextResponse, type NextRequest } from "next/server";
import { getSession } from "@/lib/auth";
import { getSeriesById, getSeriesByIds } from "@/lib/data";
import { progressSchema } from "@/lib/validation";

/**
 * Reading progress.
 *
 * Guests get a 200 with `{ ok: true, persisted: false }` so the client never
 * has to branch — it just calls this on every page turn and forgets about it.
 * Signed-in users get device sync via Prisma (`ReadingProgress`).
 */

// In-memory store standing in for `prisma.readingProgress`. Swap in the
// upsert shown in the comment below when you migrate.
const memory = new Map<string, { seriesId: string; chapterId: string; page: number; updatedAt: string }>();

export async function POST(req: NextRequest) {
  const session = await getSession();

  const body = await req.json().catch(() => null);
  const parsed = progressSchema.safeParse(body);

  if (!parsed.success) {
    return NextResponse.json(
      { error: "Invalid payload", issues: parsed.error.flatten().fieldErrors },
      { status: 400 },
    );
  }

  if (!session) {
    return NextResponse.json({ ok: true, persisted: false });
  }

  const { seriesId, chapterId, page } = parsed.data;

  memory.set(`${session.id}:${seriesId}`, {
    seriesId,
    chapterId,
    page,
    updatedAt: new Date().toISOString(),
  });

  /*
  await prisma.readingProgress.upsert({
    where: { userId_seriesId: { userId: session.id, seriesId } },
    create: { userId: session.id, seriesId, chapterId, page },
    update: { chapterId, page },
  });
  */

  return NextResponse.json({ ok: true, persisted: true });
}

/** GET /api/progress — "Continue reading" for the signed-in user. */
export async function GET() {
  const session = await getSession();

  if (!session) {
    return NextResponse.json({ items: [] });
  }

  const entries = [...memory.entries()]
    .filter(([key]) => key.startsWith(`${session.id}:`))
    .map(([, value]) => value)
    .sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());

  const series = await getSeriesByIds(entries.map((e) => e.seriesId));
  const byId = new Map(series.map((s) => [s.id, s]));

  return NextResponse.json({
    items: entries
      .filter((e) => byId.has(e.seriesId))
      .map((e) => {
        const s = byId.get(e.seriesId)!;
        return {
          seriesId: s.id,
          seriesSlug: s.slug,
          seriesTitle: s.title,
          coverUrl: s.coverUrl,
          chapterId: e.chapterId,
          chapterNumber: Number(e.chapterId.split("-c").pop()),
          page: e.page,
          totalPages: 0,
          updatedAt: e.updatedAt,
        };
      }),
  });
}
