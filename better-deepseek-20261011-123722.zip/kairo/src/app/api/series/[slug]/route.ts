import { NextResponse } from "next/server";
import { getRelated, getSeriesBySlug } from "@/lib/data";
import { signImageUrl } from "@/lib/sign-images";

/** GET /api/series/[slug] — full detail, chapters and recommendations. */
export async function GET(
  _req: Request,
  { params }: { params: { slug: string } },
) {
  const series = await getSeriesBySlug(params.slug);

  if (!series) {
    return NextResponse.json({ error: "Series not found" }, { status: 404 });
  }

  const related = await getRelated(series, 12);

  return NextResponse.json(
    {
      ...series,
      coverUrl: signImageUrl(series.coverUrl),
      bannerUrl: signImageUrl(series.bannerUrl),
      related,
    },
    { headers: { "Cache-Control": "public, s-maxage=300, stale-while-revalidate=600" } },
  );
}
