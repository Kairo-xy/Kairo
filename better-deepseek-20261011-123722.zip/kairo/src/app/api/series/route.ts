import { NextResponse, type NextRequest } from "next/server";
import { querySeries } from "@/lib/data";
import { seriesQuerySchema } from "@/lib/validation";
import { clientKey, rateLimit } from "@/lib/rate-limit";

export const dynamic = "force-dynamic";

/** GET /api/series — filter, sort and paginate the catalog. */
export async function GET(req: NextRequest) {
  const limit = rateLimit(clientKey(req, "series"), 120);
  if (!limit.ok) {
    return NextResponse.json(
      { error: "Too many requests" },
      { status: 429, headers: { "Retry-After": String(Math.ceil((limit.resetAt - Date.now()) / 1000)) } },
    );
  }

  // Build a sparse object so Zod's coercion never sees empty strings.
  const sp = req.nextUrl.searchParams;
  const raw: Record<string, unknown> = {};
  for (const key of ["q", "genres", "status", "type", "year", "minRating", "sort", "page", "limit"]) {
    const value = sp.get(key);
    if (value) raw[key] = value;
  }

  const parsed = seriesQuerySchema.safeParse(raw);
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Invalid query parameters", issues: parsed.error.flatten().fieldErrors },
      { status: 400 },
    );
  }

  const result = await querySeries(parsed.data);

  return NextResponse.json(result, {
    headers: { "Cache-Control": "public, s-maxage=60, stale-while-revalidate=300" },
  });
}
