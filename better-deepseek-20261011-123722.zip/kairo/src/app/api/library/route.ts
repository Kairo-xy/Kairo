import { NextResponse, type NextRequest } from "next/server";
import { getSession } from "@/lib/auth";
import { getSeriesById } from "@/lib/data";
import { librarySchema } from "@/lib/validation";

/**
 * Library CRUD.
 *
 * Same guest-friendly contract as `/api/progress`: unauthenticated writes are
 * acknowledged but not persisted server-side. The client mirrors them into
 * localStorage.
 */

const memory = new Map<string, { seriesId: string; status: string; updatedAt: string }>();

function key(userId: string, seriesId: string) {
  return `${userId}:${seriesId}`;
}

/** GET /api/library — every entry for the signed-in user. */
export async function GET() {
  const session = await getSession();
  if (!session) return NextResponse.json({ items: [] });

  const items = [...memory.entries()]
    .filter(([k]) => k.startsWith(`${session.id}:`))
    .map(([, v]) => v);

  return NextResponse.json({ items });
}

/** POST /api/library — add or move a series between shelves. */
export async function POST(req: NextRequest) {
  const session = await getSession();

  const parsed = librarySchema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Invalid payload", issues: parsed.error.flatten().fieldErrors },
      { status: 400 },
    );
  }

  if (!session) return NextResponse.json({ ok: true, persisted: false });

  const { seriesId, status } = parsed.data;

  // Guard against garbage IDs so a bad client can't poison the shelf.
  const series = await getSeriesById(seriesId);
  if (!series) {
    return NextResponse.json({ error: "Unknown series" }, { status: 404 });
  }

  memory.set(key(session.id, seriesId), {
    seriesId,
    status,
    updatedAt: new Date().toISOString(),
  });

  /*
  await prisma.libraryEntry.upsert({
    where: { userId_seriesId: { userId: session.id, seriesId } },
    create: { userId: session.id, seriesId, status },
    update: { status },
  });
  */

  return NextResponse.json({ ok: true, persisted: true });
}

/** DELETE /api/library?seriesId= — remove from every shelf. */
export async function DELETE(req: NextRequest) {
  const session = await getSession();
  const seriesId = req.nextUrl.searchParams.get("seriesId");

  if (!seriesId) {
    return NextResponse.json({ error: "seriesId is required" }, { status: 400 });
  }

  if (!session) return NextResponse.json({ ok: true, persisted: false });

  memory.delete(key(session.id, seriesId));

  /*
  await prisma.libraryEntry.deleteMany({
    where: { userId: session.id, seriesId },
  });
  */

  return NextResponse.json({ ok: true, persisted: true });
}
