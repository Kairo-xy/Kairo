import { NextResponse } from "next/server";
import { getChapterDetail } from "@/lib/data";
import { signImageUrl } from "@/lib/sign-images";

/**
 * GET /api/chapters/[id]
 *
 * Returns the chapter, its series, and every page with a signed CDN URL.
 * Private cache: page URLs are per-user when signing is enabled.
 */
export async function GET(_req: Request, { params }: { params: { id: string } }) {
  const data = await getChapterDetail(params.id);

  if (!data) {
    return NextResponse.json({ error: "Chapter not found" }, { status: 404 });
  }

  return NextResponse.json(
    {
      chapter: data.chapter,
      series: data.series,
      prev: data.prev,
      next: data.next,
      pages: data.pages.map((page) => ({
        ...page,
        imageUrl: signImageUrl(page.imageUrl),
      })),
    },
    { headers: { "Cache-Control": "private, max-age=300" } },
  );
}
