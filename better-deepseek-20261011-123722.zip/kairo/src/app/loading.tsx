import { PosterSkeleton, Skeleton } from "@/components/ui";

/**
 * Root loading state. The geometry matches the home page exactly, so the
 * skeleton-to-content swap produces zero layout shift.
 */
export default function Loading() {
  return (
    <div className="mx-auto max-w-[1600px] space-y-10 px-4 pt-6 sm:px-6">
      <Skeleton className="h-[380px] w-full rounded-2xl sm:h-[440px] lg:h-[500px]" />

      {[0, 1].map((row) => (
        <div key={row} className="space-y-3">
          <Skeleton className="h-5 w-40" />
          <div className="flex gap-3 overflow-hidden">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="w-[132px] shrink-0 sm:w-[148px] lg:w-[164px]">
                <PosterSkeleton />
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}
