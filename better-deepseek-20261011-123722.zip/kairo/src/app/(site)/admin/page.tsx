import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { getSession } from "@/lib/auth";
import { AdminDashboard } from "@/components/admin/admin-dashboard";
import { ALL_SERIES } from "@/lib/data";

export const metadata: Metadata = { title: "Admin", robots: { index: false } };

export default async function AdminPage() {
  const session = await getSession();

  // `middleware.ts` already gates this, but defence in depth costs nothing.
  if (!session) redirect("/login?next=/admin");
  if (session.role !== "ADMIN") redirect("/");

  return (
    <div className="pt-6">
      <h1 className="mb-6 text-xl font-semibold tracking-tight">Admin</h1>
      <AdminDashboard
        series={ALL_SERIES.map((s) => ({
          id: s.id,
          title: s.title,
          slug: s.slug,
          coverUrl: s.coverUrl,
          chapterCount: s.chapterCount,
          status: s.status,
          type: s.type,
        }))}
      />
    </div>
  );
}
