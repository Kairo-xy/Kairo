import { ContinueReadingRail } from "@/components/home/continue-reading";
import { HeroCarousel } from "@/components/series/hero-carousel";
import { Rail } from "@/components/series/rail";
import { getHomeRails } from "@/lib/data";
import { websiteJsonLd } from "@/lib/seo";
import { getSession } from "@/lib/auth";

export const revalidate = 300;

export default async function HomePage() {
  const [{ hero, trending, recentlyUpdated, newReleases, topRated }, session] =
    await Promise.all([getHomeRails(), getSession()]);

  return (
    <div className="space-y-10 pt-4 sm:pt-6">
      <script
        type="application/ld+json"
        // eslint-disable-next-line react/no-danger
        dangerouslySetInnerHTML={{ __html: JSON.stringify(websiteJsonLd()) }}
      />

      <HeroCarousel series={hero} />

      {session && <ContinueReadingRail />}

      <Rail title="Trending now" href="/browse?sort=popular" series={trending} />
      <Rail title="Recently updated" href="/browse?sort=latest" series={recentlyUpdated} />
      <Rail title="New releases" href="/browse?sort=newest" series={newReleases} />
      <Rail title="Top rated" href="/browse?sort=rating" series={topRated} />
    </div>
  );
}
