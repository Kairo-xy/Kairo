import type { Metadata } from "next";
import { LibraryView } from "@/components/library/library-view";

export const metadata: Metadata = {
  title: "Library",
  description: "Everything you're reading, planning to read, or have finished.",
};

export default function LibraryPage() {
  return (
    <div className="pt-6">
      <h1 className="mb-6 text-xl font-semibold tracking-tight">My library</h1>
      <LibraryView />
    </div>
  );
}
