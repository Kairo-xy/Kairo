import { AppShell } from "@/components/layout/app-shell";

/**
 * Everything in this route group gets the header, sidebar, footer and mobile
 * nav. `/read/*` sits outside it so the reader is truly full-bleed.
 */
export default function SiteLayout({ children }: { children: React.ReactNode }) {
  return <AppShell>{children}</AppShell>;
}
