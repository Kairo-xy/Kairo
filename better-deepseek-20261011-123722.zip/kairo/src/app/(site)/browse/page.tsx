import type { Metadata } from "next";
import { Suspense } from "react";
import { SlidersHorizontal } from "lucide-react";
import { BrowseGrid } from "@/components/browse/browse-grid";
import { BrowseToolbar } from "@/components/browse/toolbar";
import { SeriesCardSkeleton } from "@/components/series/series-card";
import { GENRES, getAvailableYears, querySeries } from "@/lib/data";
import { seriesQuerySchema } from "@/lib/validation";
import type { SeriesQuery } from "@/lib/types";

export const metadata: Metadata = {
  title: "Browse",
  description: "Filter by genre, status, type, year and rating across the whole catalog.",
};

interface PageProps {
  searchParams: Record<string, string | string[] | undefined>;
}

/** Only defined keys survive, so Zod's coercion never sees `""`. */
function parseSearchParams(sp: PageProps["searchParams"]): SeriesQuery {
  const raw: Record<string, unknown> = {};
  for (const [key, value] of Object.entries(sp)) {
    if (typeof value === "string" && value.length > 0) raw[key] = value;
  }
  const parsed = seriesQuerySchema.safeParse(raw);
  return parsed.success ? (parsed.data as SeriesQuery) : { sort: "popular", page: 1, limit: 24 };
}

export default async function BrowsePage({ searchParams }: PageProps) {
  const query = parseSearchParams(searchParams);
  const [result, years] = await Promise.all([querySeries(query), getAvailableYears()]);

  return (
    <div className="flex gap-8 pt-6">
      {/* Desktop sidebar */}
      <aside className="hidden w-56 shrink-0 lg:block">
        <div className="sticky top-[84px] max-h-[calc(100dvh-110px)] overflow-y-auto pb-8 pr-1">
          <h1 className="mb-5 text-xl font-semibold tracking-tight">Browse</h1>
          <Suspense fallback={<FilterSkeleton />}>
            <BrowseToolbar genres={GENRES} years={years} />
          </Suspense>
        </div>
      </aside>

      <div className="min-w-0 flex-1">
        <div className="mb-5 flex items-center justify-between gap-4 lg:hidden">
          <h1 className="text-xl font-semibold tracking-tight">Browse</h1>
          <Suspense fallback={null}>
            <MobileFilterTrigger genres={GENRES} years={years} />
          </Suspense>
        </div>

        <Suspense fallback={null}>
          <ActiveChips />
        </Suspense>

        <p className="mb-4 mt-3 text-[12px] text-faint">
          {result.total.toLocaleString()} series
          {query.q ? ` matching “${query.q}”` : ""}
        </p>

        <BrowseGrid
          initialItems={result.items}
          initialPage={result.page}
          totalPages={result.pages}
        />
      </div>
    </div>
  );
}

function FilterSkeleton() {
  return (
    <div className="space-y-6">
      {Array.from({ length: 4 }).map((_, i) => (
        <div key={i} className="space-y-2.5">
          <div className="h-3 w-16 animate-pulse rounded bg-surface-2" />
          <div className="h-10 w-full animate-pulse rounded-xl bg-surface-2" />
        </div>
      ))}
    </div>
  );
}

/** Thin client wrappers so the server page stays a server component. */
function MobileFilterTrigger(props: React.ComponentProps<typeof BrowseToolbar>) {
  return <BrowseToolbar {...props} variant="mobile" />;
}

function ActiveChips() {
  return <BrowseToolbar.ActiveChips genres={GENRES} />;
}
