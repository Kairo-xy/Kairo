import { Skeleton } from "@/components/ui";
import { SeriesCardSkeleton } from "@/components/series/series-card";

export default function BrowseLoading() {
  return (
    <div className="flex gap-8 pt-6">
      <aside className="hidden w-56 shrink-0 space-y-6 lg:block">
        {Array.from({ length: 4 }).map((_, i) => (
          <div key={i} className="space-y-2.5">
            <Skeleton className="h-3 w-16" />
            <Skeleton className="h-10 w-full rounded-xl" />
          </div>
        ))}
      </aside>

      <div className="min-w-0 flex-1">
        <Skeleton className="mb-4 h-5 w-28 lg:hidden" />
        <div className="grid grid-cols-2 gap-x-3 gap-y-6 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6">
          {Array.from({ length: 18 }).map((_, i) => (
            <SeriesCardSkeleton key={i} />
          ))}
        </div>
      </div>
    </div>
  );
}
