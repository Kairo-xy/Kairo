import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import { BookOpen, Calendar, Eye, Star, User } from "lucide-react";
import { Badge, Button } from "@/components/ui";
import { ChapterList } from "@/components/series/chapter-list";
import { LibraryButton } from "@/components/series/library-button";
import { SeriesCard } from "@/components/series/series-card";
import { getRelated, getSeriesBySlug } from "@/lib/data";
import { GENRE_NAME } from "@/lib/data";
import { getSession } from "@/lib/auth";
import { seriesJsonLd, absoluteUrl } from "@/lib/seo";
import { formatCompact, formatRating } from "@/lib/utils";

export const revalidate = 600;

interface PageProps {
  params: { slug: string };
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const series = await getSeriesBySlug(params.slug);
  if (!series) return { title: "Not found" };

  const description = series.description.slice(0, 155);

  return {
    title: series.title,
    description,
    alternates: { canonical: absoluteUrl(`/series/${series.slug}`) },
    openGraph: {
      title: series.title,
      description,
      type: "book",
      images: [{ url: series.coverUrl, width: 400, height: 600, alt: series.title }],
    },
    twitter: {
      card: "summary_large_image",
      title: series.title,
      description,
      images: [series.coverUrl],
    },
  };
}

const STATUS_TONE = {
  ONGOING: "success",
  COMPLETED: "accent",
  HIATUS: "warn",
  CANCELLED: "danger",
} as const;

export default async function SeriesPage({ params }: PageProps) {
  const series = await getSeriesBySlug(params.slug);
  if (!series) notFound();

  const [session, related] = await Promise.all([
    getSession(),
    getRelated(series, 12),
  ]);

  const statusLabel =
    series.status.charAt(0) + series.status.slice(1).toLowerCase();

  return (
    <article className="pt-6">
      <script
        type="application/ld+json"
        // eslint-disable-next-line react/no-danger
        dangerouslySetInnerHTML={{ __html: JSON.stringify(seriesJsonLd(series)) }}
      />

      {/* ── Hero ─────────────────────────────────────────────────────────── */}
      <div className="relative overflow-hidden rounded-2xl border border-[var(--line)]">
        <div className="absolute inset-0">
          <Image
            src={series.bannerUrl}
            alt=""
            fill
            priority
            sizes="100vw"
            className="object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[var(--bg)] via-[rgba(11,11,15,0.86)] to-[rgba(11,11,15,0.5)]" />
        </div>

        <div className="relative flex flex-col gap-6 p-5 sm:flex-row sm:p-8">
          {/* Cover */}
          <div className="mx-auto w-36 shrink-0 sm:mx-0 sm:w-44 lg:w-52">
            <div className="relative aspect-poster overflow-hidden rounded-xl border border-[var(--line)] shadow-2xl">
              <Image
                src={series.coverUrl}
                alt={series.title}
                fill
                priority
                sizes="208px"
                className="object-cover"
              />
            </div>
          </div>

          {/* Meta */}
          <div className="min-w-0 flex-1">
            <div className="mb-3 flex flex-wrap items-center gap-2">
              <Badge tone={STATUS_TONE[series.status]}>{statusLabel}</Badge>
              <Badge tone="outline">{series.type}</Badge>
              {series.genres.slice(0, 3).map((slug) => (
                <Link key={slug} href={`/browse?genres=${slug}`}>
                  <Badge tone="neutral" className="transition-colors hover:text-fg">
                    {GENRE_NAME[slug] ?? slug}
                  </Badge>
                </Link>
              ))}
            </div>

            <h1 className="text-balance text-2xl font-semibold leading-tight tracking-tight sm:text-3xl lg:text-4xl">
              {series.title}
            </h1>

            {series.altTitles.length > 0 && (
              <p className="mt-1.5 text-pretty text-[13px] text-muted">
                {series.altTitles.join(" · ")}
              </p>
            )}

            <dl className="mt-5 flex flex-wrap gap-x-6 gap-y-3 text-[13px]">
              <Stat icon={<Star className="h-3.5 w-3.5" />} label="Rating">
                <span className="font-mono">{formatRating(series.rating)}</span>
                <span className="ml-1 text-faint">
                  ({formatCompact(series.ratingCount)})
                </span>
              </Stat>
              <Stat icon={<Eye className="h-3.5 w-3.5" />} label="Reads">
                {formatCompact(series.views)}
              </Stat>
              <Stat icon={<BookOpen className="h-3.5 w-3.5" />} label="Chapters">
                {series.chapterCount}
              </Stat>
              <Stat icon={<Calendar className="h-3.5 w-3.5" />} label="Year">
                {series.releaseYear}
              </Stat>
            </dl>

            <p className="mt-4 flex flex-wrap items-center gap-x-5 gap-y-1.5 text-[13px] text-muted">
              <span className="flex items-center gap-1.5">
                <User className="h-3.5 w-3.5 text-faint" />
                {series.author}
              </span>
              <span className="text-faint">Art by {series.artist}</span>
            </p>

            <div className="mt-6 flex flex-wrap gap-2.5">
              <Link href={`/read/${series.chapters[series.chapters.length - 1]?.id ?? ""}`}>
                <Button size="lg">
                  <BookOpen className="h-4 w-4" />
                  Start reading
                </Button>
              </Link>
              <LibraryButton seriesId={series.id} isAuthenticated={Boolean(session)} />
            </div>
          </div>
        </div>
      </div>

      {/* ── Body ─────────────────────────────────────────────────────────── */}
      <div className="mt-8 grid gap-8 lg:grid-cols-[1fr_340px]">
        <div className="min-w-0 space-y-8">
          <section>
            <h2 className="mb-3 text-[15px] font-semibold tracking-tight">Synopsis</h2>
            <p className="text-pretty text-[14px] leading-relaxed text-muted">
              {series.description}
            </p>
          </section>

          <section>
            <div className="mb-3 flex items-end justify-between">
              <h2 className="text-[15px] font-semibold tracking-tight">
                Chapters
                <span className="ml-2 font-mono text-[12px] font-normal text-faint">
                  {series.chapterCount}
                </span>
              </h2>
            </div>
            <ChapterList seriesId={series.id} chapters={series.chapters} />
          </section>
        </div>

        <aside className="space-y-6">
          <section>
            <h2 className="mb-3 text-[15px] font-semibold tracking-tight">Genres</h2>
            <div className="flex flex-wrap gap-1.5">
              {series.genres.map((slug) => (
                <Link key={slug} href={`/browse?genres=${slug}`}>
                  <Badge
                    tone="neutral"
                    className="px-2.5 py-1.5 text-[12px] transition-colors hover:bg-surface-3 hover:text-fg"
                  >
                    {GENRE_NAME[slug] ?? slug}
                  </Badge>
                </Link>
              ))}
            </div>
          </section>

          <section>
            <h2 className="mb-3 text-[15px] font-semibold tracking-tight">
              You might also like
            </h2>
            <div className="grid grid-cols-3 gap-3">
              {related.slice(0, 6).map((s) => (
                <SeriesCard key={s.id} series={s} />
              ))}
            </div>
          </section>
        </aside>
      </div>
    </article>
  );
}

function Stat({
  icon,
  label,
  children,
}: {
  icon: React.ReactNode;
  label: string;
  children: React.ReactNode;
}) {
  return (
    <div>
      <dt className="flex items-center gap-1.5 text-[11px] uppercase tracking-wider text-faint">
        {icon}
        {label}
      </dt>
      <dd className="mt-0.5 font-medium text-fg">{children}</dd>
    </div>
  );
}
