import type { Metadata } from "next";
import { SearchResults } from "@/components/search/search-results";

export const metadata: Metadata = {
  title: "Search",
  description: "Find series by title, author, artist or genre.",
};

export default function SearchPage({
  searchParams,
}: {
  searchParams: { q?: string };
}) {
  return (
    <div className="pt-6">
      <h1 className="mb-6 text-xl font-semibold tracking-tight">Search</h1>
      <SearchResults initialQuery={searchParams.q ?? ""} />
    </div>
  );
}
