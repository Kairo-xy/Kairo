import type { Metadata } from "next";
import { redirect } from "next/navigation";
import Image from "next/image";
import { BookOpen, Clock, Star, TrendingUp } from "lucide-react";
import { Badge, Button, Card } from "@/components/ui";
import { ThemeToggle } from "@/components/layout/theme-toggle";
import { getSession } from "@/lib/auth";

export const metadata: Metadata = { title: "Profile" };

export default async function ProfilePage() {
  const session = await getSession();
  if (!session) redirect("/login?next=/profile");

  // Stats are illustrative in the demo; wire these to Prisma aggregates.
  const stats = [
    { label: "Chapters read", value: "1,284", icon: BookOpen },
    { label: "Series followed", value: "37", icon: Star },
    { label: "Hours read", value: "212", icon: Clock },
    { label: "Current streak", value: "18 days", icon: TrendingUp },
  ];

  return (
    <div className="space-y-8 pt-6">
      <header className="flex flex-col items-start gap-5 sm:flex-row sm:items-center">
        <div className="relative h-20 w-20 shrink-0 overflow-hidden rounded-2xl border border-[var(--line)] bg-surface-2">
          {session.avatar ? (
            <Image src={session.avatar} alt="" fill sizes="80px" className="object-cover" />
          ) : (
            <span className="grid h-full w-full place-items-center text-2xl font-semibold text-accent">
              {session.username.slice(0, 1).toUpperCase()}
            </span>
          )}
        </div>

        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-2.5">
            <h1 className="text-2xl font-semibold tracking-tight">{session.username}</h1>
            {session.role === "ADMIN" && <Badge tone="accent">Admin</Badge>}
          </div>
          <p className="mt-1 text-[13px] text-muted">{session.email}</p>
        </div>

        <div className="flex gap-2">
          {session.role === "ADMIN" && (
            <a href="/admin">
              <Button variant="outline">Admin panel</Button>
            </a>
          )}
        </div>
      </header>

      <section className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {stats.map(({ label, value, icon: Icon }) => (
          <Card key={label} className="p-4">
            <Icon className="mb-3 h-4 w-4 text-faint" />
            <p className="font-mono text-xl font-semibold tabular-nums">{value}</p>
            <p className="mt-0.5 text-[12px] text-muted">{label}</p>
          </Card>
        ))}
      </section>

      <section className="grid gap-6 lg:grid-cols-2">
        <Card className="p-5">
          <h2 className="mb-4 text-[15px] font-semibold tracking-tight">Appearance</h2>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-[13px]">Theme</p>
              <p className="mt-0.5 text-[12px] text-faint">
                Dark by default. The reader respects this too.
              </p>
            </div>
            <ThemeToggle />
          </div>
        </Card>

        <Card className="p-5">
          <h2 className="mb-4 text-[15px] font-semibold tracking-tight">Reading</h2>
          <div className="space-y-3 text-[13px]">
            {[
              ["Save progress across devices", "On"],
              ["Auto-mark chapters as read", "On"],
              ["Email me about new chapters", "Off"],
            ].map(([label, value]) => (
              <div key={label} className="flex items-center justify-between">
                <span className="text-muted">{label}</span>
                <Badge tone={value === "On" ? "accent" : "neutral"}>{value}</Badge>
              </div>
            ))}
          </div>
        </Card>
      </section>
    </div>
  );
}
