import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { Reader } from "@/components/reader/reader";
import { getChapterDetail } from "@/lib/data";
import { getSession } from "@/lib/auth";
import { formatChapterNumber } from "@/lib/utils";

interface PageProps {
  params: { chapterId: string };
}

/**
 * The reader lives outside the `(site)` route group, so it renders without
 * header, sidebar or footer. Only the chapter's own chrome remains.
 */
export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const data = await getChapterDetail(params.chapterId);
  if (!data) return { title: "Chapter not found" };

  return {
    title: `${data.series.title} — Chapter ${formatChapterNumber(data.chapter.number)}`,
    description: `Read ${data.series.title} chapter ${formatChapterNumber(data.chapter.number)} online.`,
    // Chapter pages are thin; keep crawlers focused on the series page.
    robots: { index: false, follow: true },
  };
}

export default async function ReadPage({ params }: PageProps) {
  const [data, session] = await Promise.all([
    getChapterDetail(params.chapterId),
    getSession(),
  ]);

  if (!data) notFound();

  return <Reader data={data} isAuthenticated={Boolean(session)} />;
}
