import type { MetadataRoute } from "next";
import { ALL_SERIES } from "@/lib/data";

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000";

export default function sitemap(): MetadataRoute.Sitemap {
  const staticRoutes: MetadataRoute.Sitemap = [
    { url: SITE_URL, changeFrequency: "daily", priority: 1 },
    { url: `${SITE_URL}/browse`, changeFrequency: "daily", priority: 0.9 },
  ];

  const seriesRoutes: MetadataRoute.Sitemap = ALL_SERIES.map((series) => ({
    url: `${SITE_URL}/series/${series.slug}`,
    lastModified: new Date(series.latestChapterAt),
    changeFrequency: "weekly",
    priority: 0.8,
  }));

  return [...staticRoutes, ...seriesRoutes];
}
