import Link from "next/link";
import { Button } from "@/components/ui";

export default function NotFound() {
  return (
    <div className="mx-auto flex min-h-dvh max-w-md flex-col items-center justify-center px-6 text-center">
      <p className="font-mono text-[11px] uppercase tracking-[0.2em] text-faint">404</p>
      <h1 className="mt-3 text-2xl font-semibold tracking-tight">Nothing here</h1>
      <p className="mt-2 text-[14px] leading-relaxed text-muted">
        The page you were looking for has moved, been unpublished, or never existed.
      </p>
      <div className="mt-7 flex gap-2.5">
        <Link href="/">
          <Button>Back home</Button>
        </Link>
        <Link href="/browse">
          <Button variant="outline">Browse series</Button>
        </Link>
      </div>
    </div>
  );
}
