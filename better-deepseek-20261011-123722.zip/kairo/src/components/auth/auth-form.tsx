"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { AlertCircle } from "lucide-react";
import { Button, Input } from "@/components/ui";

type Mode = "login" | "register";

/**
 * Auth form.
 *
 * The demo endpoints accept any valid email plus a password of sufficient
 * length — see `src/lib/auth.ts`. Swapping in NextAuth means changing the
 * `fetch` targets to `signIn("credentials", …)` and nothing else.
 */
export function AuthForm({ mode, next }: { mode: Mode; next?: string }) {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      const endpoint = mode === "login" ? "/api/auth/login" : "/api/auth/register";
      const body = mode === "login" ? { email, password } : { email, username, password };

      const res = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });

      if (!res.ok) {
        const data = (await res.json().catch(() => ({}))) as { error?: string };
        setError(data.error ?? "Something went wrong. Try again.");
        return;
      }

      router.push(next && next.startsWith("/") ? next : "/");
      router.refresh();
    } catch {
      setError("Network error. Check your connection and try again.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="space-y-5">
      <div className="grid grid-cols-2 gap-2">
        <OAuthButton provider="Google" />
        <OAuthButton provider="Discord" />
      </div>

      <div className="flex items-center gap-3">
        <span className="h-px flex-1 bg-[var(--line)]" />
        <span className="text-[11px] uppercase tracking-wider text-faint">or</span>
        <span className="h-px flex-1 bg-[var(--line)]" />
      </div>

      <form onSubmit={onSubmit} className="space-y-3.5">
        {mode === "register" && (
          <Field label="Username">
            <Input
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="yourname"
              autoComplete="username"
              pattern="[a-zA-Z0-9_]{3,24}"
              required
            />
          </Field>
        )}

        <Field label="Email">
          <Input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="you@example.com"
            autoComplete="email"
            required
          />
        </Field>

        <Field label="Password">
          <Input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder={mode === "register" ? "At least 8 characters" : "••••••••"}
            autoComplete={mode === "login" ? "current-password" : "new-password"}
            minLength={mode === "register" ? 8 : 4}
            required
          />
        </Field>

        {error && (
          <p
            role="alert"
            className="flex items-start gap-2 rounded-xl bg-[rgba(244,82,95,0.1)] px-3.5 py-2.5 text-[12px] text-danger"
          >
            <AlertCircle className="mt-0.5 h-3.5 w-3.5 shrink-0" />
            {error}
          </p>
        )}

        <Button type="submit" size="lg" className="w-full" loading={loading}>
          {mode === "login" ? "Sign in" : "Create account"}
        </Button>
      </form>

      {mode === "login" && (
        <div className="rounded-xl border border-dashed border-[var(--line-strong)] px-3.5 py-3">
          <p className="text-[11px] leading-relaxed text-faint">
            <span className="font-medium text-muted">Demo:</span> any valid email works, with a
            password of 4+ characters. Use an address starting with{" "}
            <code className="rounded bg-surface-3 px-1 py-0.5 font-mono text-[10px]">admin@</code>{" "}
            to get the admin panel.
          </p>
        </div>
      )}
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-[13px] font-medium text-muted">{label}</span>
      {children}
    </label>
  );
}

function OAuthButton({ provider }: { provider: "Google" | "Discord" }) {
  return (
    <button
      type="button"
      // Wire to signIn(provider) once NextAuth is installed.
      onClick={() => alert(`${provider} sign-in is enabled once NextAuth is configured.`)}
      className="flex h-10 items-center justify-center gap-2 rounded-xl border border-[var(--line-strong)] text-[13px] font-medium text-muted transition-colors duration-150 hover:bg-surface-2 hover:text-fg"
    >
      {provider}
    </button>
  );
}
