"use client";

import { useEffect, useRef, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Loader2, Search, Star, TrendingUp } from "lucide-react";
import { cn, formatChapterNumber, formatRating } from "@/lib/utils";
import { useDebouncedValue } from "@/hooks/use-debounced-value";
import { api } from "@/lib/api-client";
import type { Series } from "@/lib/types";

const TRENDING = ["Shadow", "Romance", "Isekai", "Martial Arts", "Thriller"];

/**
 * ⌘K search palette.
 *
 * Requests are debounced 200ms and the previous in-flight request is aborted
 * on every keystroke, so a fast typist never sees stale results overwrite
 * fresh ones.
 */
export function SearchCommand({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<Series[]>([]);
  const [loading, setLoading] = useState(false);
  const debounced = useDebouncedValue(query, 200);
  const inputRef = useRef<HTMLInputElement>(null);
  const router = useRouter();

  useEffect(() => {
    if (!open) return;
    setQuery("");
    setResults([]);
    // Focus after the paint so the browser doesn't scroll-jump.
    const id = requestAnimationFrame(() => inputRef.current?.focus());
    return () => cancelAnimationFrame(id);
  }, [open]);

  useEffect(() => {
    if (!open) return;

    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onOpenChange(false);
    };
    window.addEventListener("keydown", onKey);

    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";

    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = prev;
    };
  }, [open, onOpenChange]);

  useEffect(() => {
    if (!debounced.trim()) {
      setResults([]);
      setLoading(false);
      return;
    }

    const controller = new AbortController();
    setLoading(true);

    fetch(`/api/search?q=${encodeURIComponent(debounced)}&limit=8`, {
      signal: controller.signal,
    })
      .then((r) => (r.ok ? r.json() : { items: [] }))
      .then((data: { items: Series[] }) => {
        setResults(data.items ?? []);
      })
      .catch((err) => {
        if ((err as Error).name !== "AbortError") setResults([]);
      })
      .finally(() => setLoading(false));

    return () => controller.abort();
  }, [debounced]);

  function go(href: string) {
    onOpenChange(false);
    router.push(href);
  }

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[80] flex items-start justify-center px-4 pt-[10vh]" role="dialog" aria-modal="true" aria-label="Search">
      <button
        className="absolute inset-0 bg-[var(--scrim)] backdrop-blur-sm"
        onClick={() => onOpenChange(false)}
        aria-label="Close search"
      />

      <div className="relative w-full max-w-xl animate-slide-up overflow-hidden rounded-2xl border border-[var(--line)] bg-surface shadow-2xl">
        <div className="flex items-center gap-3 border-b border-[var(--line)] px-4">
          <Search className="h-4 w-4 shrink-0 text-faint" />
          <input
            ref={inputRef}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && query.trim()) {
                go(`/search?q=${encodeURIComponent(query.trim())}`);
              }
            }}
            placeholder="Search series, authors, genres…"
            aria-label="Search query"
            className="h-14 flex-1 bg-transparent text-[15px] text-fg outline-none placeholder:text-faint"
          />
          {loading && <Loader2 className="h-4 w-4 shrink-0 animate-spin text-faint" />}
          <kbd className="hidden shrink-0 rounded border border-[var(--line-strong)] px-1.5 py-0.5 font-mono text-[10px] text-faint sm:block">
            ESC
          </kbd>
        </div>

        <div className="max-h-[60vh] overflow-y-auto overscroll-contain p-2">
          {!query.trim() && (
            <div className="p-3">
              <p className="mb-2 flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wider text-faint">
                <TrendingUp className="h-3.5 w-3.5" />
                Popular searches
              </p>
              <div className="flex flex-wrap gap-1.5">
                {TRENDING.map((t) => (
                  <button
                    key={t}
                    onClick={() => setQuery(t)}
                    className="rounded-lg bg-surface-2 px-2.5 py-1.5 text-[12px] text-muted transition-colors hover:bg-surface-3 hover:text-fg"
                  >
                    {t}
                  </button>
                ))}
              </div>
            </div>
          )}

          {query.trim() && !loading && results.length === 0 && (
            <p className="px-3 py-8 text-center text-[13px] text-faint">
              No results for “{query}”.
            </p>
          )}

          {results.map((series) => (
            <button
              key={series.id}
              onClick={() => go(`/series/${series.slug}`)}
              className="flex w-full items-center gap-3 rounded-xl p-2 text-left transition-colors duration-150 hover:bg-surface-2"
            >
              <div className="relative h-16 w-11 shrink-0 overflow-hidden rounded-lg border border-[var(--line)] bg-surface-2">
                <Image
                  src={series.coverUrl}
                  alt=""
                  fill
                  sizes="44px"
                  className="object-cover"
                />
              </div>

              <div className="min-w-0 flex-1">
                <p className="truncate text-[13px] font-medium">{series.title}</p>
                <p className="mt-0.5 truncate text-[11px] text-faint">
                  {series.author} · Ch. {formatChapterNumber(series.latestChapter)}
                </p>
              </div>

              <span className="flex shrink-0 items-center gap-1 text-[11px] text-muted">
                <Star className="h-3 w-3 fill-[var(--warn)] text-[var(--warn)]" />
                <span className="font-mono">{formatRating(series.rating)}</span>
              </span>
            </button>
          ))}

          {query.trim() && results.length > 0 && (
            <Link
              href={`/search?q=${encodeURIComponent(query.trim())}`}
              onClick={() => onOpenChange(false)}
              className={cn(
                "mt-1 block rounded-xl px-3 py-2.5 text-center text-[12px] font-medium",
                "text-accent transition-colors duration-150 hover:bg-[var(--accent-soft)]",
              )}
            >
              See all results for “{query}”
            </Link>
          )}
        </div>
      </div>
    </div>
  );
}
