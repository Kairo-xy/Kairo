"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { Loader2, Search as SearchIcon } from "lucide-react";
import { EmptyState, Input, Tabs } from "@/components/ui";
import { SeriesCard, SeriesCardSkeleton } from "@/components/series/series-card";
import { useDebouncedValue } from "@/hooks/use-debounced-value";
import { api } from "@/lib/api-client";
import type { Series } from "@/lib/types";

type Scope = "series" | "authors" | "genres";

export function SearchResults({ initialQuery }: { initialQuery: string }) {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [query, setQuery] = useState(initialQuery);
  const [scope, setScope] = useState<Scope>("series");
  const [items, setItems] = useState<Series[]>([]);
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);
  const debounced = useDebouncedValue(query, 300);
  const inputRef = useRef<HTMLInputElement>(null);

  // Keep the input and the URL in sync when navigating in from the header.
  useEffect(() => {
    const fromUrl = searchParams.get("q") ?? "";
    if (fromUrl !== query) setQuery(fromUrl);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [searchParams]);

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  useEffect(() => {
    if (!debounced.trim()) {
      setItems([]);
      setSearched(false);
      return;
    }

    let cancelled = false;
    setLoading(true);

    api
      .search(debounced, 48)
      .then((res) => {
        if (cancelled) return;
        setItems(res.items);
        setSearched(true);
      })
      .catch(() => {
        if (!cancelled) setItems([]);
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });

    return () => {
      cancelled = true;
    };
  }, [debounced]);

  // Reflect the query in the URL so results are shareable.
  useEffect(() => {
    const current = searchParams.get("q") ?? "";
    if (debounced.trim() === current) return;
    const params = new URLSearchParams(searchParams.toString());
    if (debounced.trim()) params.set("q", debounced.trim());
    else params.delete("q");
    router.replace(`/search?${params.toString()}`, { scroll: false });
  }, [debounced, router, searchParams]);

  const authors = Array.from(new Set(items.map((s) => s.author)));
  const genres = Array.from(new Set(items.flatMap((s) => s.genres)));

  return (
    <div className="space-y-6">
      <div className="relative">
        <SearchIcon className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-faint" />
        <Input
          ref={inputRef}
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search by title, author, artist or genre…"
          aria-label="Search"
          className="h-12 pl-10 text-[15px]"
        />
        {loading && (
          <Loader2 className="absolute right-3.5 top-1/2 h-4 w-4 -translate-y-1/2 animate-spin text-faint" />
        )}
      </div>

      {searched && (
        <Tabs
          value={scope}
          onChange={(v) => setScope(v as Scope)}
          items={[
            { value: "series", label: "Series", count: items.length },
            { value: "authors", label: "Authors", count: authors.length },
            { value: "genres", label: "Genres", count: genres.length },
          ]}
          className="w-fit"
        />
      )}

      {loading && (
        <div className="grid grid-cols-2 gap-x-3 gap-y-6 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">
          {Array.from({ length: 12 }).map((_, i) => (
            <SeriesCardSkeleton key={i} />
          ))}
        </div>
      )}

      {!loading && scope === "series" && items.length > 0 && (
        <div className="grid grid-cols-2 gap-x-3 gap-y-6 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">
          {items.map((s, i) => (
            <SeriesCard key={s.id} series={s} priority={i < 6} />
          ))}
        </div>
      )}

      {!loading && scope === "authors" && (
        <ul className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
          {authors.map((author) => (
            <li key={author}>
              <button
                onClick={() => setQuery(author)}
                className="w-full rounded-xl border border-[var(--line)] bg-surface px-4 py-3 text-left text-[13px] transition-colors hover:bg-surface-2"
              >
                {author}
              </button>
            </li>
          ))}
        </ul>
      )}

      {!loading && scope === "genres" && (
        <div className="flex flex-wrap gap-2">
          {genres.map((genre) => (
            <button
              key={genre}
              onClick={() => setQuery(genre)}
              className="rounded-lg bg-surface-3 px-3 py-2 text-[13px] capitalize text-muted transition-colors hover:bg-surface-2 hover:text-fg"
            >
              {genre.replace(/-/g, " ")}
            </button>
          ))}
        </div>
      )}

      {!loading && searched && items.length === 0 && (
        <EmptyState
          title={`No results for “${debounced}”`}
          description="Check the spelling, try a shorter query, or search by the author's name instead."
        />
      )}

      {!searched && !loading && (
        <p className="py-16 text-center text-[13px] text-faint">
          Start typing to search across every series in the catalog.
        </p>
      )}
    </div>
  );
}
