"use client";

import { useEffect, useMemo, useState } from "react";
import { Bookmark, Library as LibraryIcon } from "lucide-react";
import { EmptyState, Tabs } from "@/components/ui";
import { SeriesCard, SeriesCardSkeleton } from "@/components/series/series-card";
import { api } from "@/lib/api-client";
import { getGuestLibrary } from "@/lib/reading-store";
import type { LibraryStatus, Series } from "@/lib/types";

const TABS: { value: LibraryStatus | "ALL"; label: string }[] = [
  { value: "ALL", label: "All" },
  { value: "READING", label: "Reading" },
  { value: "PLAN_TO_READ", label: "Plan to read" },
  { value: "COMPLETED", label: "Completed" },
  { value: "ON_HOLD", label: "On hold" },
  { value: "DROPPED", label: "Dropped" },
  { value: "BOOKMARKS", label: "Bookmarks" } as never,
];

/**
 * Library view.
 *
 * Guests read from localStorage; signed-in users hit the API. Both resolve to
 * the same `Series[]` shape so the grid below is identical.
 */
export function LibraryView() {
  const [tab, setTab] = useState<LibraryStatus | "ALL">("ALL");
  const [items, setItems] = useState<Series[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;

    async function load() {
      setLoading(true);

      // Try the server first. If the user is a guest, fall back to localStorage.
      try {
        const res = await api.listLibrary();
        const entries = res.items as { seriesId: string; status: LibraryStatus }[];
        if (entries.length) {
          const detailed = await Promise.all(
            entries.map((e) => api.seriesDetail(e.seriesId).catch(() => null)),
          );
          const resolved = detailed.filter((s): s is NonNullable<typeof s> => Boolean(s));
          if (!cancelled) setItems(resolved as unknown as Series[]);
          setLoading(false);
          return;
        }
      } catch {
        /* not signed in — fall through */
      }

      // Guest path
      const guest = getGuestLibrary();
      const ids = Object.keys(guest);
      if (!ids.length) {
        if (!cancelled) setItems([]);
        setLoading(false);
        return;
      }

      const results = await Promise.all(
        ids.map((id) => api.seriesDetail(id).catch(() => null)),
      );
      if (!cancelled) {
        setItems(results.filter((s): s is NonNullable<typeof s> => Boolean(s)) as unknown as Series[]);
      }
      setLoading(false);
    }

    void load();
    window.addEventListener("kairo:store", load);
    return () => {
      cancelled = true;
      window.removeEventListener("kairo:store", load);
    };
  }, []);

  const counts = useMemo(() => {
    const map: Record<string, number> = {};
    for (const item of items) {
      const status = (item as unknown as { libraryStatus?: LibraryStatus }).libraryStatus ?? "READING";
      map[status] = (map[status] ?? 0) + 1;
    }
    map.ALL = items.length;
    return map;
  }, [items]);

  if (loading) {
    return (
      <div className="grid grid-cols-2 gap-x-3 gap-y-6 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">
        {Array.from({ length: 12 }).map((_, i) => (
          <SeriesCardSkeleton key={i} />
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Tabs
        items={TABS.map((t) => ({ ...t, count: counts[t.value] ?? 0 }))}
        value={tab}
        onChange={(v) => setTab(v as LibraryStatus | "ALL")}
      />

      {items.length === 0 ? (
        <EmptyState
          icon={<LibraryIcon className="h-6 w-6" />}
          title="Your library is empty"
          description="Add series from any detail page and they'll show up here — organised by what you're reading, planning, or have finished."
        />
      ) : (
        <div className="grid grid-cols-2 gap-x-3 gap-y-6 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">
          {items.map((s) => (
            <SeriesCard key={s.id} series={s} />
          ))}
        </div>
      )}

      <p className="flex items-center justify-center gap-1.5 pt-4 text-[12px] text-faint">
        <Bookmark className="h-3.5 w-3.5" />
        Bookmarks are saved per page inside the reader.
      </p>
    </div>
  );
}
