"use client";

import Link from "next/link";
import Image from "next/image";
import { ArrowLeft, ArrowRight, Check, Home, List } from "lucide-react";
import { Button } from "@/components/ui";
import { formatChapterNumber } from "@/lib/utils";
import type { Chapter, Series } from "@/lib/types";

interface EndCardProps {
  series: Series;
  chapter: Chapter;
  prev: Chapter | null;
  next: Chapter | null;
  onClose: () => void;
}

/**
 * Shown at the end of a chapter. Deliberately generous — this is the moment a
 * reader decides whether to keep going, so the next action should be obvious
 * and require zero thought.
 */
export function EndCard({ series, chapter, prev, next, onClose }: EndCardProps) {
  return (
    <div className="mx-auto max-w-2xl px-4 py-14">
      <div className="overflow-hidden rounded-2xl border border-[var(--line)] bg-surface">
        <div className="relative h-32 w-full sm:h-40">
          <Image src={series.bannerUrl} alt="" fill sizes="640px" className="object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-[var(--surface)] to-transparent" />
        </div>

        <div className="px-6 pb-6 pt-2 sm:px-8">
          <div className="mb-5 flex items-center gap-2 text-[12px] font-medium text-success">
            <span className="grid h-5 w-5 place-items-center rounded-full bg-[rgba(62,207,142,0.16)]">
              <Check className="h-3 w-3" />
            </span>
            Chapter complete
          </div>

          <h2 className="text-xl font-semibold tracking-tight">{series.title}</h2>
          <p className="mt-1 text-[13px] text-muted">
            Chapter {formatChapterNumber(chapter.number)}
            {chapter.title && chapter.title !== `Chapter ${chapter.number}`
              ? ` — ${chapter.title}`
              : ""}
          </p>

          <div className="mt-7 flex flex-col gap-2.5 sm:flex-row">
            {next ? (
              <Link href={`/read/${next.id}`} className="flex-1">
                <Button className="w-full" size="lg">
                  Next chapter
                  <ArrowRight className="h-4 w-4" />
                </Button>
              </Link>
            ) : (
              <Button className="flex-1" size="lg" disabled>
                You're all caught up
              </Button>
            )}

            {prev && (
              <Link href={`/read/${prev.id}`} className="flex-1">
                <Button variant="outline" size="lg" className="w-full">
                  <ArrowLeft className="h-4 w-4" />
                  Previous
                </Button>
              </Link>
            )}
          </div>

          <div className="mt-3 flex gap-2.5">
            <Link href={`/series/${series.slug}`} className="flex-1">
              <Button variant="ghost" className="w-full">
                <List className="h-4 w-4" />
                All chapters
              </Button>
            </Link>
            <Link href="/" className="flex-1">
              <Button variant="ghost" className="w-full">
                <Home className="h-4 w-4" />
                Home
              </Button>
            </Link>
          </div>
        </div>
      </div>

      <button
        onClick={onClose}
        className="mx-auto mt-6 block text-[12px] text-faint transition-colors hover:text-muted"
      >
        Hide
      </button>
    </div>
  );
}
