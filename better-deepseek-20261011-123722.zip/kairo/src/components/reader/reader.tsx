"use client";

import {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Home,
  List,
  Loader2,
  Maximize,
  Minimize,
  Settings2,
  X,
} from "lucide-react";
import { Button, Drawer } from "@/components/ui";
import { ReaderSettingsPanel } from "./reader-settings";
import { EndCard } from "./end-card";
import {
  clamp,
  cn,
  formatChapterNumber,
} from "@/lib/utils";
import { useLocalStorage } from "@/hooks/use-local-storage";
import {
  markChapterRead,
  saveProgress,
} from "@/lib/reading-store";
import { api } from "@/lib/api-client";
import {
  DEFAULT_READER_SETTINGS,
  type Chapter,
  type ChapterDetail,
  type Page,
  type ReaderSettings,
} from "@/lib/types";

const SETTINGS_KEY = "kairo:reader";
const PRELOAD_AHEAD = 3;

const BACKGROUNDS: Record<ReaderSettings["background"], string> = {
  black: "#000000",
  gray: "#1a1a1a",
  white: "#ffffff",
};

interface ReaderProps {
  data: ChapterDetail;
  isAuthenticated: boolean;
}

/**
 * ─────────────────────────────────────────────────────────────────────────────
 * READER
 * ─────────────────────────────────────────────────────────────────────────────
 *
 * This is the product. Everything else is navigation to get here.
 *
 * Design decisions worth knowing:
 *
 *  • Pages are rendered as plain <img> rather than next/image. The optimizer
 *    re-encodes every page, which adds latency to the one interaction where
 *    latency is most noticeable. The CDN already serves WebP/AVIF.
 *
 *  • Progress is written to localStorage synchronously on every page turn
 *    (cheap, never lost) and to the server on a 1.2s debounce (batches the
 *    flurry of turns at the end of a chapter into one request).
 *
 *  • The toolbar hides on a timer but any pointer movement, key press or
 *    scroll brings it back. Touch devices get a tap-to-toggle instead, since
 *    there's no hover to reveal it.
 */
export function Reader({ data, isAuthenticated }: ReaderProps) {
  const { chapter, series, pages, prev, next } = data;
  const router = useRouter();

  const [settings, setSettings, settingsReady, resetSettings] =
    useLocalStorage<ReaderSettings>(SETTINGS_KEY, DEFAULT_READER_SETTINGS);

  const [pageIndex, setPageIndex] = useState(0);
  const [toolbarVisible, setToolbarVisible] = useState(true);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [chapterMenuOpen, setChapterMenuOpen] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showEndCard, setShowEndCard] = useState(false);
  const [brokenPages, setBrokenPages] = useState<Set<number>>(new Set());

  const hideTimer = useRef<ReturnType<typeof setTimeout>>();
  const saveTimer = useRef<ReturnType<typeof setTimeout>>();
  const stageRef = useRef<HTMLDivElement>(null);

  const total = pages.length;

  // ─── Derived page window ───────────────────────────────────────────────────

  const isSpread = settings.mode === "double";

  /**
   * In double-page mode we step by 2. RTL flips which page is "first" so that
   * the right-hand page is always the earlier one, matching how manga is read.
   */
  const visibleIndices = useMemo(() => {
    if (!isSpread) return [pageIndex];
    if (settings.direction === "rtl") {
      return [pageIndex + 1, pageIndex].filter((i) => i < total);
    }
    return [pageIndex, pageIndex + 1].filter((i) => i < total);
  }, [isSpread, pageIndex, total, settings.direction]);

  const step = isSpread ? 2 : 1;

  // ─── Navigation ────────────────────────────────────────────────────────────

  const goToPage = useCallback(
    (index: number) => {
      const target = clamp(index, 0, Math.max(0, total - 1));
      setPageIndex(target);
      setShowEndCard(false);
      if (settings.mode !== "strip") {
        window.scrollTo({ top: 0, behavior: "auto" });
      }
    },
    [total, settings.mode],
  );

  const nextPage = useCallback(() => {
    if (pageIndex + step >= total) {
      setShowEndCard(true);
      return;
    }
    goToPage(pageIndex + step);
  }, [pageIndex, step, total, goToPage]);

  const prevPage = useCallback(() => {
    if (showEndCard) {
      setShowEndCard(false);
      goToPage(total - 1);
      return;
    }
    goToPage(pageIndex - step);
  }, [pageIndex, step, goToPage, showEndCard, total]);

  const goToChapter = useCallback(
    (target: Chapter) => {
      router.push(`/read/${target.id}`);
    },
    [router],
  );

  // ─── Progress persistence ──────────────────────────────────────────────────

  useEffect(() => {
    if (!settingsReady) return;

    saveProgress({
      seriesId: series.id,
      seriesSlug: series.slug,
      seriesTitle: series.title,
      coverUrl: series.coverUrl,
      chapterId: chapter.id,
      chapterNumber: chapter.number,
      page: pageIndex,
      totalPages: total,
      updatedAt: new Date().toISOString(),
    });

    if (pageIndex >= total - 1) markChapterRead(chapter.id);

    if (saveTimer.current) clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(() => {
      if (isAuthenticated) {
        api
          .saveProgress({ seriesId: series.id, chapterId: chapter.id, page: pageIndex })
          .catch(() => {
            /* offline or expired session — localStorage already has it */
          });
      }
    }, 1200);

    return () => {
      if (saveTimer.current) clearTimeout(saveTimer.current);
    };
  }, [
    pageIndex,
    series.id,
    series.slug,
    series.title,
    series.coverUrl,
    chapter.id,
    chapter.number,
    total,
    isAuthenticated,
    settingsReady,
  ]);

  // ─── Preload the next few pages ────────────────────────────────────────────

  useEffect(() => {
    if (settings.mode === "strip") return;
    for (let i = 1; i <= PRELOAD_AHEAD; i++) {
      const target = pages[pageIndex + i * step];
      if (!target) break;
      const img = new window.Image();
      img.decoding = "async";
      img.src = target.imageUrl;
    }
  }, [pageIndex, step, pages, settings.mode]);

  // ─── Keyboard ──────────────────────────────────────────────────────────────

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      if (target?.tagName === "INPUT" || target?.tagName === "TEXTAREA") return;

      // RTL flips the arrow keys so "forward" always means forward.
      const forward = settings.direction === "ltr" ? "ArrowRight" : "ArrowLeft";
      const backward = settings.direction === "ltr" ? "ArrowLeft" : "ArrowRight";

      switch (e.key) {
        case forward:
          e.preventDefault();
          nextPage();
          revealToolbar();
          break;
        case backward:
          e.preventDefault();
          prevPage();
          revealToolbar();
          break;
        case "ArrowDown":
          if (settings.mode === "strip") break;
          e.preventDefault();
          nextPage();
          break;
        case "ArrowUp":
          if (settings.mode === "strip") break;
          e.preventDefault();
          prevPage();
          break;
        case " ":
        case "Spacebar":
          e.preventDefault();
          nextPage();
          break;
        case "f":
        case "F":
          e.preventDefault();
          void toggleFullscreen();
          break;
        case "s":
        case "S":
          e.preventDefault();
          setSettingsOpen((o) => !o);
          break;
        case "Escape":
          if (settingsOpen) {
            setSettingsOpen(false);
          } else if (document.fullscreenElement) {
            void document.exitFullscreen();
          } else {
            router.push(`/series/${series.slug}`);
          }
          break;
      }
    };

    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [nextPage, prevPage, settings.direction, settings.mode, settingsOpen, router, series.slug]);

  // ─── Fullscreen ────────────────────────────────────────────────────────────

  const toggleFullscreen = useCallback(async () => {
    try {
      if (document.fullscreenElement) {
        await document.exitFullscreen();
      } else {
        await document.documentElement.requestFullscreen();
      }
    } catch {
      /* Safari on iOS refuses programmatic fullscreen — not worth surfacing */
    }
  }, []);

  useEffect(() => {
    const onFsChange = () => setIsFullscreen(Boolean(document.fullscreenElement));
    document.addEventListener("fullscreenchange", onFsChange);
    return () => document.removeEventListener("fullscreenchange", onFsChange);
  }, []);

  // ─── Auto-hiding toolbar ───────────────────────────────────────────────────

  const revealToolbar = useCallback(() => {
    setToolbarVisible(true);
    if (hideTimer.current) clearTimeout(hideTimer.current);
    if (!settings.autoHideToolbar) return;
    hideTimer.current = setTimeout(() => setToolbarVisible(false), 2800);
  }, [settings.autoHideToolbar]);

  useEffect(() => {
    revealToolbar();
    const onMove = () => revealToolbar();
    window.addEventListener("mousemove", onMove);
    window.addEventListener("touchstart", onMove, { passive: true });
    return () => {
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("touchstart", onMove);
      if (hideTimer.current) clearTimeout(hideTimer.current);
    };
  }, [revealToolbar]);

  // ─── Strip mode: track the page in view ────────────────────────────────────

  useEffect(() => {
    if (settings.mode !== "strip") return;

    const container = stageRef.current;
    if (!container) return;

    const observer = new IntersectionObserver(
      (entries) => {
        let bestIndex = -1;
        let bestRatio = 0;
        for (const entry of entries) {
          if (entry.intersectionRatio > bestRatio) {
            bestRatio = entry.intersectionRatio;
            bestIndex = Number((entry.target as HTMLElement).dataset.index);
          }
        }
        if (bestIndex >= 0) setPageIndex(bestIndex);
      },
      { root: null, threshold: [0.1, 0.5, 0.9] },
    );

    container.querySelectorAll("[data-reader-page]").forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, [settings.mode, pages.length]);

  // ─── Render ────────────────────────────────────────────────────────────────

  const background = BACKGROUNDS[settings.background];
  const isLightBackground = settings.background === "white";

  const fitClasses = (() => {
    switch (settings.fit) {
      case "width":
        return "w-full h-auto";
      case "height":
        return "h-full w-auto";
      case "original":
      default:
        return "max-h-full max-w-full w-auto h-auto";
    }
  })();

  const chromeColors = isLightBackground
    ? "text-black/80 hover:bg-black/5"
    : "text-white/80 hover:bg-white/10";

  return (
    <div
      className="relative min-h-dvh"
      style={{ backgroundColor: background }}
      data-reader
    >
      <style>{`[data-reader] ::selection { background: transparent; }`}</style>

      {/* ── Header ───────────────────────────────────────────────────────── */}
      <header
        className={cn(
          "safe-top fixed inset-x-0 top-0 z-40 transition-all duration-300",
          toolbarVisible
            ? "translate-y-0 opacity-100"
            : "-translate-y-full opacity-0 pointer-events-none",
        )}
      >
        <div
          className={cn(
            "border-b backdrop-blur-xl",
            isLightBackground
              ? "border-black/10 bg-white/80"
              : "border-white/10 bg-[rgba(0,0,0,0.72)]",
          )}
        >
          <div className="flex h-14 items-center gap-2 px-3 sm:px-4">
            <Link
              href={`/series/${series.slug}`}
              aria-label="Back to series"
              className={cn("rounded-lg p-2 transition-colors", chromeColors)}
            >
              <ChevronLeft className="h-5 w-5" />
            </Link>

            <div className="min-w-0 flex-1">
              <Link
                href={`/series/${series.slug}`}
                className={cn(
                  "block truncate text-[13px] font-medium",
                  isLightBackground ? "text-black" : "text-white",
                )}
              >
                {series.title}
              </Link>
              <p
                className={cn(
                  "truncate text-[11px]",
                  isLightBackground ? "text-black/50" : "text-white/50",
                )}
              >
                Chapter {formatChapterNumber(chapter.number)}
                {chapter.title !== `Chapter ${chapter.number}` && ` · ${chapter.title}`}
              </p>
            </div>

            {/* Chapter switcher */}
            <div className="relative">
              <button
                onClick={() => setChapterMenuOpen((o) => !o)}
                aria-label="Choose chapter"
                aria-expanded={chapterMenuOpen}
                className={cn("flex items-center gap-1 rounded-lg p-2 transition-colors", chromeColors)}
              >
                <List className="h-[18px] w-[18px]" />
                <ChevronDown className="h-3.5 w-3.5" />
              </button>

              {chapterMenuOpen && (
                <>
                  <button
                    className="fixed inset-0 z-40 cursor-default"
                    aria-label="Close chapter list"
                    onClick={() => setChapterMenuOpen(false)}
                  />
                  <div className="absolute right-0 z-50 mt-2 max-h-[60vh] w-64 overflow-y-auto rounded-xl border border-[var(--line)] bg-surface p-1 shadow-2xl">
                    {[next, { ...chapter, id: chapter.id, number: chapter.number } as Chapter, prev]
                      .filter((c): c is Chapter => Boolean(c))
                      .map((c) => (
                        <Link
                          key={c.id}
                          href={`/read/${c.id}`}
                          onClick={() => setChapterMenuOpen(false)}
                          className={cn(
                            "block rounded-lg px-3 py-2 text-[13px] transition-colors",
                            c.id === chapter.id
                              ? "bg-[var(--accent-soft)] text-accent"
                              : "text-muted hover:bg-surface-2 hover:text-fg",
                          )}
                        >
                          Ch. {formatChapterNumber(c.number)}
                        </Link>
                      ))}
                    <Link
                      href={`/series/${series.slug}`}
                      onClick={() => setChapterMenuOpen(false)}
                      className="mt-1 block rounded-lg border-t border-[var(--line)] px-3 py-2.5 text-[12px] font-medium text-accent"
                    >
                      View all chapters →
                    </Link>
                  </div>
                </>
              )}
            </div>

            <button
              onClick={() => setSettingsOpen(true)}
              aria-label="Reader settings"
              className={cn("rounded-lg p-2 transition-colors", chromeColors)}
            >
              <Settings2 className="h-[18px] w-[18px]" />
            </button>

            <button
              onClick={toggleFullscreen}
              aria-label={isFullscreen ? "Exit fullscreen" : "Enter fullscreen"}
              className={cn("hidden rounded-lg p-2 transition-colors sm:block", chromeColors)}
            >
              {isFullscreen ? <Minimize className="h-[18px] w-[18px]" /> : <Maximize className="h-[18px] w-[18px]" />}
            </button>

            <Link
              href={`/series/${series.slug}`}
              aria-label="Exit reader"
              className={cn("rounded-lg p-2 transition-colors", chromeColors)}
            >
              <X className="h-[18px] w-[18px]" />
            </Link>
          </div>
        </div>
      </header>

      {/* ── Stage ────────────────────────────────────────────────────────── */}
      <div
        ref={stageRef}
        className={cn(
          "min-h-dvh",
          settings.mode === "strip" ? "pt-0 pb-24" : "flex items-center justify-center pb-20 pt-16",
        )}
        style={{
          filter: `brightness(${settings.brightness}%)`,
          gap: settings.mode === "strip" ? settings.gap : undefined,
        }}
      >
        {settings.mode === "strip" ? (
          <div
            className="mx-auto flex w-full max-w-[900px] flex-col items-center"
            style={{ gap: settings.gap }}
          >
            {pages.map((page) => (
              <StripPage
                key={page.id}
                page={page}
                broken={brokenPages.has(page.index)}
                onError={() =>
                  setBrokenPages((prev) => new Set(prev).add(page.index))
                }
              />
            ))}
          </div>
        ) : (
          <div
            className="flex h-[calc(100dvh-9rem)] w-full items-center justify-center"
            style={{ gap: settings.gap }}
            dir={settings.direction === "rtl" ? "rtl" : "ltr"}
          >
            {visibleIndices.map((index) => (
              <PageImage
                key={pages[index]?.id ?? index}
                page={pages[index]}
                fitClasses={fitClasses}
                broken={brokenPages.has(index)}
                onError={() => setBrokenPages((prev) => new Set(prev).add(index))}
              />
            ))}
          </div>
        )}
      </div>

      {/* ── Click zones (paged modes only) ───────────────────────────────── */}
      {settings.mode !== "strip" && !showEndCard && (
        <div className="fixed inset-0 z-10 flex" aria-hidden>
          <button
            onClick={settings.direction === "ltr" ? prevPage : nextPage}
            className="h-full w-1/3 cursor-w-resize focus-visible:bg-white/5"
            aria-label={settings.direction === "ltr" ? "Previous page" : "Next page"}
            tabIndex={-1}
          />
          <button
            onClick={() => setToolbarVisible((v) => !v)}
            className="h-full w-1/3 focus-visible:bg-white/5"
            aria-label="Toggle controls"
            tabIndex={-1}
          />
          <button
            onClick={settings.direction === "ltr" ? nextPage : prevPage}
            className="h-full w-1/3 cursor-e-resize focus-visible:bg-white/5"
            aria-label={settings.direction === "ltr" ? "Next page" : "Previous page"}
            tabIndex={-1}
          />
        </div>
      )}

      {/* ── End card ─────────────────────────────────────────────────────── */}
      {showEndCard && (
        <div
          className="relative z-30"
          style={{ backgroundColor: background }}
        >
          <EndCard
            series={series}
            chapter={chapter}
            prev={prev}
            next={next}
            onClose={() => setShowEndCard(false)}
          />
        </div>
      )}

      {/* ── Footer ───────────────────────────────────────────────────────── */}
      <footer
        className={cn(
          "safe-bottom fixed inset-x-0 bottom-0 z-40 transition-all duration-300",
          toolbarVisible
            ? "translate-y-0 opacity-100"
            : "translate-y-full opacity-0 pointer-events-none",
        )}
      >
        <div
          className={cn(
            "border-t backdrop-blur-xl",
            isLightBackground
              ? "border-black/10 bg-white/80"
              : "border-white/10 bg-[rgba(0,0,0,0.72)]",
          )}
        >
          <div className="flex h-16 items-center gap-3 px-3 sm:px-5">
            <button
              onClick={prev ? () => goToChapter(prev) : undefined}
              disabled={!prev}
              aria-label="Previous chapter"
              className={cn(
                "rounded-lg p-2 transition-colors disabled:opacity-30",
                chromeColors,
              )}
            >
              <ChevronLeft className="h-5 w-5" />
            </button>

            <div className="flex flex-1 items-center gap-3">
              <span
                className={cn(
                  "shrink-0 font-mono text-[12px] tabular-nums",
                  isLightBackground ? "text-black/70" : "text-white/70",
                )}
              >
                {pageIndex + 1}
                {isSpread && pageIndex + 1 < total ? `–${Math.min(pageIndex + 2, total)}` : ""}
                <span className={isLightBackground ? "text-black/35" : "text-white/35"}>
                  {" / "}
                  {total}
                </span>
              </span>

              <input
                type="range"
                min={0}
                max={Math.max(0, total - 1)}
                value={pageIndex}
                aria-label="Page"
                onChange={(e) => goToPage(Number(e.target.value))}
                className="h-1.5 flex-1 cursor-pointer appearance-none rounded-full bg-white/20 accent-[var(--accent)]
                           [&::-webkit-slider-thumb]:h-3.5 [&::-webkit-slider-thumb]:w-3.5 [&::-webkit-slider-thumb]:appearance-none
                           [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-accent"
              />
            </div>

            <button
              onClick={next ? () => goToChapter(next) : undefined}
              disabled={!next}
              aria-label="Next chapter"
              className={cn(
                "rounded-lg p-2 transition-colors disabled:opacity-30",
                chromeColors,
              )}
            >
              <ChevronRight className="h-5 w-5" />
            </button>

            <Link
              href="/"
              aria-label="Home"
              className={cn("hidden rounded-lg p-2 transition-colors sm:block", chromeColors)}
            >
              <Home className="h-[18px] w-[18px]" />
            </Link>
          </div>
        </div>
      </footer>

      {/* ── Settings ─────────────────────────────────────────────────────── */}
      <ReaderSettingsPanel
        open={settingsOpen}
        onClose={() => setSettingsOpen(false)}
        settings={settings}
        onChange={(patch) => setSettings((s) => ({ ...s, ...patch }))}
        onReset={resetSettings}
      />
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Page renderers
// ─────────────────────────────────────────────────────────────────────────────

function PageImage({
  page,
  fitClasses,
  broken,
  onError,
}: {
  page?: Page;
  fitClasses: string;
  broken: boolean;
  onError: () => void;
}) {
  if (!page) return null;

  if (broken) {
    return (
      <div className="grid min-h-[60vh] w-full max-w-lg place-items-center rounded-xl border border-white/10 bg-white/5 px-6 text-center">
        <div>
          <p className="text-[13px] font-medium text-white/80">Page failed to load</p>
          <p className="mt-1 text-[12px] text-white/50">
            Page {page.index + 1} couldn't be fetched. Try refreshing.
          </p>
        </div>
      </div>
    );
  }

  return (
    // eslint-disable-next-line @next/next/no-img-element -- see component docblock
    <img
      src={page.imageUrl}
      alt={`Page ${page.index + 1}`}
      width={page.width}
      height={page.height}
      decoding="async"
      draggable={false}
      onError={onError}
      className={cn("reader-page select-none object-contain", fitClasses)}
    />
  );
}

function StripPage({
  page,
  broken,
  onError,
}: {
  page: Page;
  broken: boolean;
  onError: () => void;
}) {
  return (
    <div
      data-reader-page
      data-index={page.index}
      className="w-full"
      style={{ aspectRatio: `${page.width} / ${page.height}` }}
    >
      {broken ? (
        <div className="grid h-full w-full place-items-center rounded-lg border border-white/10 bg-white/5">
          <span className="text-[12px] text-white/50">Page {page.index + 1} unavailable</span>
        </div>
      ) : (
        // eslint-disable-next-line @next/next/no-img-element
        <img
          src={page.imageUrl}
          alt={`Page ${page.index + 1}`}
          width={page.width}
          height={page.height}
          loading={page.index < 3 ? "eager" : "lazy"}
          decoding="async"
          draggable={false}
          onError={onError}
          className="reader-page block h-auto w-full select-none"
        />
      )}
    </div>
  );
}
