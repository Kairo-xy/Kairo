"use client";

import { Grip, Maximize2, Monitor, Moon, Sun, ZoomIn } from "lucide-react";
import { Segmented, Slider, Switch, Drawer } from "@/components/ui";
import type { ReaderSettings } from "@/lib/types";

interface ReaderSettingsPanelProps {
  open: boolean;
  onClose: () => void;
  settings: ReaderSettings;
  onChange: (patch: Partial<ReaderSettings>) => void;
  onReset: () => void;
}

export function ReaderSettingsPanel({
  open,
  onClose,
  settings,
  onChange,
  onReset,
}: ReaderSettingsPanelProps) {
  return (
    <Drawer open={open} onClose={onClose} title="Reader settings" side="right">
      <div className="space-y-6 p-5">
        <Segmented
          label="Layout"
          value={settings.mode}
          onChange={(mode) => onChange({ mode })}
          options={[
            { value: "single", label: "Single", icon: <Monitor className="h-3.5 w-3.5" /> },
            { value: "double", label: "Spread", icon: <Grip className="h-3.5 w-3.5" /> },
            { value: "strip", label: "Webtoon", icon: <Maximize2 className="h-3.5 w-3.5" /> },
          ]}
        />

        {settings.mode !== "strip" && (
          <Segmented
            label="Fit"
            value={settings.fit}
            onChange={(fit) => onChange({ fit })}
            options={[
              { value: "width", label: "Width" },
              { value: "height", label: "Height" },
              { value: "original", label: "Original", icon: <ZoomIn className="h-3.5 w-3.5" /> },
            ]}
          />
        )}

        <Segmented
          label="Reading direction"
          value={settings.direction}
          onChange={(direction) => onChange({ direction })}
          options={[
            { value: "ltr", label: "Left → Right" },
            { value: "rtl", label: "Right → Left" },
          ]}
        />

        <Segmented
          label="Background"
          value={settings.background}
          onChange={(background) => onChange({ background })}
          options={[
            { value: "black", label: "Black", icon: <Moon className="h-3.5 w-3.5" /> },
            { value: "gray", label: "Gray" },
            { value: "white", label: "White", icon: <Sun className="h-3.5 w-3.5" /> },
          ]}
        />

        <Slider
          label="Brightness"
          min={40}
          max={140}
          step={5}
          value={settings.brightness}
          onChange={(brightness) => onChange({ brightness })}
          format={(v) => `${v}%`}
        />

        <Slider
          label={settings.mode === "strip" ? "Gap between pages" : "Gap between spreads"}
          min={0}
          max={48}
          step={4}
          value={settings.gap}
          onChange={(gap) => onChange({ gap })}
          format={(v) => `${v}px`}
        />

        <Segmented
          label="Image quality"
          value={settings.quality}
          onChange={(quality) => onChange({ quality })}
          options={[
            { value: "low", label: "Data saver" },
            { value: "medium", label: "Balanced" },
            { value: "high", label: "Original" },
          ]}
        />

        <div className="border-t border-[var(--line)] pt-5">
          <Switch
            label="Auto-hide toolbar"
            checked={settings.autoHideToolbar}
            onChange={(autoHideToolbar) => onChange({ autoHideToolbar })}
          />
        </div>

        <div className="border-t border-[var(--line)] pt-5">
          <button
            onClick={onReset}
            className="w-full rounded-xl border border-[var(--line-strong)] px-4 py-2.5 text-[13px] font-medium text-muted transition-colors duration-150 hover:bg-surface-2 hover:text-fg"
          >
            Reset to defaults
          </button>
        </div>

        <div className="rounded-xl bg-surface-2 p-3.5">
          <p className="mb-2 text-[11px] font-semibold uppercase tracking-wider text-faint">
            Keyboard
          </p>
          <dl className="space-y-1.5 text-[12px]">
            {[
              ["← / →", "Previous / next page"],
              ["↑ / ↓", "Scroll"],
              ["Space", "Next page"],
              ["F", "Fullscreen"],
              ["S", "Settings"],
              ["Esc", "Exit reader"],
            ].map(([key, action]) => (
              <div key={key} className="flex items-center justify-between gap-3">
                <dt className="font-mono text-faint">{key}</dt>
                <dd className="text-muted">{action}</dd>
              </div>
            ))}
          </dl>
        </div>
      </div>
    </Drawer>
  );
}
