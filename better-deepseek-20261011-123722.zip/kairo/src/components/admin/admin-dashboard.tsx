"use client";

import { useCallback, useMemo, useRef, useState } from "react";
import Image from "next/image";
import {
  Check,
  GripVertical,
  ImagePlus,
  Trash2,
  Upload,
  Users,
} from "lucide-react";
import { Badge, Button, Card, Input, Select, Tabs, Textarea } from "@/components/ui";
import { cn, naturalCompare } from "@/lib/utils";
import type { SeriesStatus, SeriesType } from "@/lib/types";

interface AdminSeries {
  id: string;
  title: string;
  slug: string;
  coverUrl: string;
  chapterCount: number;
  status: SeriesStatus;
  type: SeriesType;
}

const TABS = [
  { value: "series", label: "Series" },
  { value: "upload", label: "Upload chapter" },
  { value: "comments", label: "Comments" },
  { value: "users", label: "Users" },
];

export function AdminDashboard({ series }: { series: AdminSeries[] }) {
  const [tab, setTab] = useState("series");

  return (
    <Tabs items={TABS} value={tab} onChange={setTab} className="w-fit" />

    <div className="mt-6">
      {tab === "series" && <SeriesPanel series={series} />}
      {tab === "upload" && <UploadPanel series={series} />}
      {tab === "comments" && <CommentsPanel />}
      {tab === "users" && <UsersPanel />}
    </div>
  );
}

// ─── Series ──────────────────────────────────────────────────────────────────

function SeriesPanel({ series }: { series: AdminSeries[] }) {
  const [query, setQuery] = useState("");
  const [status, setStatus] = useState<SeriesStatus | "ALL">("ALL");

  const filtered = useMemo(() => {
    const needle = query.trim().toLowerCase();
    return series.filter((s) => {
      if (status !== "ALL" && s.status !== status) return false;
      if (!needle) return true;
      return s.title.toLowerCase().includes(needle) || s.slug.includes(needle);
    });
  }, [series, query, status]);

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-2">
        <Input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search series…"
          className="max-w-xs"
        />
        <Select
          value={status}
          onChange={(e) => setStatus(e.target.value as SeriesStatus | "ALL")}
          className="max-w-[180px]"
        >
          <option value="ALL">All statuses</option>
          <option value="ONGOING">Ongoing</option>
          <option value="COMPLETED">Completed</option>
          <option value="HIATUS">Hiatus</option>
          <option value="CANCELLED">Cancelled</option>
        </Select>
        <div className="flex-1" />
        <Button>
          <ImagePlus className="h-4 w-4" />
          New series
        </Button>
      </div>

      <Card className="overflow-hidden">
        <table className="w-full text-left text-[13px]">
          <thead className="border-b border-[var(--line)] text-[11px] uppercase tracking-wider text-faint">
            <tr>
              <th className="px-4 py-3 font-medium">Title</th>
              <th className="hidden px-4 py-3 font-medium sm:table-cell">Type</th>
              <th className="hidden px-4 py-3 font-medium md:table-cell">Chapters</th>
              <th className="px-4 py-3 font-medium">Status</th>
              <th className="px-4 py-3" />
            </tr>
          </thead>
          <tbody className="divide-y divide-[var(--line)]">
            {filtered.slice(0, 60).map((s) => (
              <tr key={s.id} className="transition-colors hover:bg-surface-2">
                <td className="px-4 py-3">
                  <div className="flex items-center gap-3">
                    <div className="relative h-12 w-8 shrink-0 overflow-hidden rounded border border-[var(--line)] bg-surface-2">
                      <Image src={s.coverUrl} alt="" fill sizes="32px" className="object-cover" />
                    </div>
                    <div className="min-w-0">
                      <p className="truncate font-medium">{s.title}</p>
                      <p className="truncate font-mono text-[11px] text-faint">/{s.slug}</p>
                    </div>
                  </div>
                </td>
                <td className="hidden px-4 py-3 text-muted sm:table-cell">
                  {s.type.charAt(0) + s.type.slice(1).toLowerCase()}
                </td>
                <td className="hidden px-4 py-3 font-mono text-muted md:table-cell">
                  {s.chapterCount}
                </td>
                <td className="px-4 py-3">
                  <Badge tone={s.status === "ONGOING" ? "success" : "neutral"}>
                    {s.status.charAt(0) + s.status.slice(1).toLowerCase()}
                  </Badge>
                </td>
                <td className="px-4 py-3 text-right">
                  <Button variant="ghost" size="sm">
                    Edit
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>

      <p className="text-[12px] text-faint">
        Showing {Math.min(filtered.length, 60)} of {filtered.length}
      </p>
    </div>
  );
}

// ─── Upload ──────────────────────────────────────────────────────────────────

interface StagedFile {
  id: string;
  file: File;
  previewUrl: string;
}

function UploadPanel({ series }: { series: AdminSeries[] }) {
  const [seriesId, setSeriesId] = useState(series[0]?.id ?? "");
  const [number, setNumber] = useState("");
  const [title, setTitle] = useState("");
  const [files, setFiles] = useState<StagedFile[]>([]);
  const [dragging, setDragging] = useState(false);
  const [publishing, setPublishing] = useState(false);
  const [published, setPublished] = useState(false);
  const dragIndex = useRef<number | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const addFiles = useCallback((incoming: FileList | File[]) => {
    const images = Array.from(incoming).filter((f) => f.type.startsWith("image/"));
    if (!images.length) return;

    // Sort by filename first — the overwhelmingly common case is that the
    // uploader already named pages 001.png, 002.png, …
    images.sort((a, b) => naturalCompare(a.name, b.name));

    setFiles((prev) => [
      ...prev,
      ...images.map((file) => ({
        id: `${file.name}-${file.size}-${Math.random().toString(36).slice(2, 8)}`,
        file,
        previewUrl: URL.createObjectURL(file),
      })),
    ]);
  }, []);

  function move(from: number, to: number) {
    setFiles((prev) => {
      const next = prev.slice();
      const [moved] = next.splice(from, 1);
      next.splice(to, 0, moved);
      return next;
    });
  }

  async function publish() {
    if (!files.length || !seriesId || !number) return;

    setPublishing(true);
    try {
      const res = await fetch("/api/admin/chapters", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          seriesId,
          number: Number(number),
          title: title || undefined,
          pageKeys: files.map((f) => f.file.name),
        }),
      });
      if (res.ok) {
        setPublished(true);
        setTimeout(() => setPublished(false), 3000);
      }
    } finally {
      setPublishing(false);
    }
  }

  return (
    <div className="grid gap-6 lg:grid-cols-[1fr_320px]">
      <div className="space-y-4">
        <div
          onDragOver={(e) => {
            e.preventDefault();
            setDragging(true);
          }}
          onDragLeave={() => setDragging(false)}
          onDrop={(e) => {
            e.preventDefault();
            setDragging(false);
            addFiles(e.dataTransfer.files);
          }}
          className={cn(
            "flex flex-col items-center justify-center gap-3 rounded-2xl border-2 border-dashed px-6 py-14 text-center transition-colors duration-150",
            dragging
              ? "border-accent bg-[var(--accent-soft)]"
              : "border-[var(--line-strong)] hover:border-[var(--line-strong)]",
          )}
        >
          <Upload className={cn("h-7 w-7", dragging ? "text-accent" : "text-faint")} />
          <div>
            <p className="text-[14px] font-medium">Drop page images here</p>
            <p className="mt-1 text-[12px] text-muted">
              Files are sorted by filename. Drag rows below to reorder.
            </p>
          </div>
          <Button variant="outline" size="sm" onClick={() => inputRef.current?.click()}>
            Choose files
          </Button>
          <input
            ref={inputRef}
            type="file"
            accept="image/*"
            multiple
            hidden
            onChange={(e) => e.target.files && addFiles(e.target.files)}
          />
        </div>

        {files.length > 0 && (
          <Card className="overflow-hidden">
            <div className="flex items-center justify-between border-b border-[var(--line)] px-4 py-3">
              <p className="text-[13px] font-medium">{files.length} pages</p>
              <button
                onClick={() => setFiles([])}
                className="text-[12px] text-danger transition-colors hover:underline"
              >
                Clear all
              </button>
            </div>

            <ul className="max-h-[420px] divide-y divide-[var(--line)] overflow-y-auto">
              {files.map((f, i) => (
                <li
                  key={f.id}
                  draggable
                  onDragStart={() => (dragIndex.current = i)}
                  onDragOver={(e) => e.preventDefault()}
                  onDrop={() => {
                    if (dragIndex.current !== null && dragIndex.current !== i) {
                      move(dragIndex.current, i);
                    }
                    dragIndex.current = null;
                  }}
                  className="flex items-center gap-3 px-3 py-2 transition-colors hover:bg-surface-2"
                >
                  <GripVertical className="h-4 w-4 shrink-0 cursor-grab text-faint" />
                  <span className="w-8 shrink-0 font-mono text-[11px] text-faint">{i + 1}</span>
                  <div className="relative h-12 w-9 shrink-0 overflow-hidden rounded border border-[var(--line)]">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img src={f.previewUrl} alt="" className="h-full w-full object-cover" />
                  </div>
                  <span className="min-w-0 flex-1 truncate text-[12px] text-muted">
                    {f.file.name}
                  </span>
                  <button
                    onClick={() => setFiles((prev) => prev.filter((x) => x.id !== f.id))}
                    aria-label={`Remove ${f.file.name}`}
                    className="rounded-lg p-1.5 text-faint transition-colors hover:bg-surface-3 hover:text-danger"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </li>
              ))}
            </ul>
          </Card>
        )}
      </div>

      <Card className="h-fit space-y-4 p-5">
        <h2 className="text-[15px] font-semibold tracking-tight">Chapter details</h2>

        <label className="block">
          <span className="mb-1.5 block text-[13px] font-medium text-muted">Series</span>
          <Select value={seriesId} onChange={(e) => setSeriesId(e.target.value)}>
            {series.map((s) => (
              <option key={s.id} value={s.id}>
                {s.title}
              </option>
            ))}
          </Select>
        </label>

        <label className="block">
          <span className="mb-1.5 block text-[13px] font-medium text-muted">Chapter number</span>
          <Input
            type="number"
            step="0.1"
            min="0"
            value={number}
            onChange={(e) => setNumber(e.target.value)}
            placeholder="e.g. 42"
          />
        </label>

        <label className="block">
          <span className="mb-1.5 block text-[13px] font-medium text-muted">
            Title <span className="text-faint">(optional)</span>
          </span>
          <Textarea
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Chapter title"
            className="min-h-20"
          />
        </label>

        <Button
          className="w-full"
          size="lg"
          disabled={!files.length || !number || !seriesId}
          loading={publishing}
          onClick={publish}
        >
          {published ? (
            <>
              <Check className="h-4 w-4" />
              Published
            </>
          ) : (
            <>
              <Upload className="h-4 w-4" />
              Publish chapter
            </>
          )}
        </Button>

        <p className="text-[11px] leading-relaxed text-faint">
          Pages upload to object storage, then a signed CDN URL is written per page. Publishing is
          atomic — the chapter only becomes visible once every page is confirmed.
        </p>
      </Card>
    </div>
  );
}

// ─── Comments ────────────────────────────────────────────────────────────────

function CommentsPanel() {
  return (
    <Card className="p-6">
      <p className="text-[13px] text-muted">
        Comment moderation queues by chapter. Wire this to{" "}
        <code className="rounded bg-surface-3 px-1.5 py-0.5 font-mono text-[11px]">
          prisma.comment.findMany
        </code>{" "}
        with a <code className="rounded bg-surface-3 px-1.5 py-0.5 font-mono text-[11px]">reported</code>{" "}
        filter.
      </p>
    </Card>
  );
}

// ─── Users ───────────────────────────────────────────────────────────────────

function UsersPanel() {
  return (
    <Card className="p-6">
      <div className="flex items-start gap-3">
        <Users className="mt-0.5 h-4 w-4 shrink-0 text-faint" />
        <p className="text-[13px] leading-relaxed text-muted">
          User management: role changes, bans, and account merges. Backed by{" "}
          <code className="rounded bg-surface-3 px-1.5 py-0.5 font-mono text-[11px]">
            prisma.user
          </code>
          . Reads are already exposed via <code className="rounded bg-surface-3 px-1.5 py-0.5 font-mono text-[11px]">/api/library</code>{" "}
          and <code className="rounded bg-surface-3 px-1.5 py-0.5 font-mono text-[11px]">/api/progress</code>.
        </p>
      </div>
    </Card>
  );
}
