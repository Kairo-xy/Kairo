"use client";

import { useMemo, useState } from "react";
import { useSearchParams } from "next/navigation";
import { SlidersHorizontal } from "lucide-react";
import { Filters } from "./filters";
import { Button } from "@/components/ui";

interface BrowseToolbarProps {
  genres: { name: string; slug: string }[];
  years: number[];
  variant?: "sidebar" | "mobile";
}

/**
 * Client boundary for the filter panel.
 *
 * The desktop variant renders inline; the mobile variant renders a trigger
 * button that opens a bottom drawer.
 */
export function BrowseToolbar({ genres, years, variant = "sidebar" }: BrowseToolbarProps) {
  const [open, setOpen] = useState(false);
  const searchParams = useSearchParams();

  const activeCount = useMemo(() => {
    let n = 0;
    for (const key of ["genres", "type", "status"]) {
      const raw = searchParams.get(key);
      if (raw) n += raw.split(",").filter(Boolean).length;
    }
    if (searchParams.get("year")) n += 1;
    if (searchParams.get("minRating")) n += 1;
    return n;
  }, [searchParams]);

  if (variant === "mobile") {
    return (
      <>
        <Button variant="outline" size="sm" onClick={() => setOpen(true)}>
          <SlidersHorizontal className="h-3.5 w-3.5" />
          Filters
          {activeCount > 0 && (
            <span className="ml-0.5 rounded bg-accent px-1.5 font-mono text-[10px] text-accent-fg">
              {activeCount}
            </span>
          )}
        </Button>
        <Filters
          genres={genres}
          years={years}
          variant="drawer"
          open={open}
          onOpenChange={setOpen}
        />
      </>
    );
  }

  return <Filters genres={genres} years={years} />;
}

BrowseToolbar.ActiveChips = function ActiveChips({
  genres,
}: {
  genres: { name: string; slug: string }[];
}) {
  const searchParams = useSearchParams();
  const { ActiveFilterChips } = require("./filters") as typeof import("./filters");

  const hasAny =
    searchParams.get("genres") ||
    searchParams.get("type") ||
    searchParams.get("status") ||
    searchParams.get("year") ||
    searchParams.get("minRating");

  if (!hasAny) return null;
  return <ActiveFilterChips genres={genres} />;
};
