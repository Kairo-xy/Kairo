"use client";

import { useCallback, useMemo } from "react";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { RotateCcw, SlidersHorizontal, X } from "lucide-react";
import { Badge, Button, Drawer, Select, Slider } from "@/components/ui";
import { cn } from "@/lib/utils";
import type { SeriesStatus, SeriesType } from "@/lib/types";

interface FiltersProps {
  genres: { name: string; slug: string }[];
  years: number[];
  /** Mobile renders into a drawer; desktop renders inline. */
  variant?: "sidebar" | "drawer";
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
}

const SORTS = [
  { value: "popular", label: "Most popular" },
  { value: "latest", label: "Recently updated" },
  { value: "rating", label: "Highest rated" },
  { value: "newest", label: "Newest" },
  { value: "az", label: "A → Z" },
];

const TYPES: SeriesType[] = ["MANGA", "MANHWA", "MANHUA", "WEBTOON"];
const STATUSES: SeriesStatus[] = ["ONGOING", "COMPLETED", "HIATUS", "CANCELLED"];

function titleCase(s: string) {
  return s.charAt(0) + s.slice(1).toLowerCase();
}

/**
 * Filter panel.
 *
 * All state lives in the URL, which means filters are shareable, back/forward
 * works, and the server component can read them without a client store.
 */
export function Filters({
  genres,
  years,
  variant = "sidebar",
  open = false,
  onOpenChange,
}: FiltersProps) {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();

  const selected = useMemo(
    () => ({
      genres: (searchParams.get("genres") ?? "").split(",").filter(Boolean),
      type: (searchParams.get("type") ?? "").split(",").filter(Boolean),
      status: (searchParams.get("status") ?? "").split(",").filter(Boolean),
      year: searchParams.get("year") ?? "",
      minRating: Number(searchParams.get("minRating") ?? 0),
      sort: searchParams.get("sort") ?? "popular",
    }),
    [searchParams],
  );

  const setParam = useCallback(
    (key: string, value: string | null) => {
      const params = new URLSearchParams(searchParams.toString());
      if (value) params.set(key, value);
      else params.delete(key);
      params.delete("page"); // any filter change resets pagination
      router.push(`${pathname}?${params.toString()}`, { scroll: false });
    },
    [pathname, router, searchParams],
  );

  const toggleMulti = useCallback(
    (key: "genres" | "type" | "status", value: string) => {
      const current = selected[key];
      const next = current.includes(value)
        ? current.filter((v) => v !== value)
        : [...current, value];
      setParam(key, next.length ? next.join(",") : null);
    },
    [selected, setParam],
  );

  const activeCount =
    selected.genres.length +
    selected.type.length +
    selected.status.length +
    (selected.year ? 1 : 0) +
    (selected.minRating > 0 ? 1 : 0);

  function reset() {
    router.push(pathname, { scroll: false });
  }

  const body = (
    <div className="space-y-6">
      <FilterGroup title="Sort by">
        <Select
          value={selected.sort}
          onChange={(e) => setParam("sort", e.target.value)}
          aria-label="Sort results"
        >
          {SORTS.map((s) => (
            <option key={s.value} value={s.value}>
              {s.label}
            </option>
          ))}
        </Select>
      </FilterGroup>

      <FilterGroup title="Type">
        <div className="flex flex-wrap gap-1.5">
          {TYPES.map((t) => (
            <Chip
              key={t}
              active={selected.type.includes(t)}
              onClick={() => toggleMulti("type", t)}
            >
              {titleCase(t)}
            </Chip>
          ))}
        </div>
      </FilterGroup>

      <FilterGroup title="Status">
        <div className="flex flex-wrap gap-1.5">
          {STATUSES.map((s) => (
            <Chip
              key={s}
              active={selected.status.includes(s)}
              onClick={() => toggleMulti("status", s)}
            >
              {titleCase(s)}
            </Chip>
          ))}
        </div>
      </FilterGroup>

      <FilterGroup title="Release year">
        <Select
          value={selected.year}
          onChange={(e) => setParam("year", e.target.value || null)}
          aria-label="Release year"
        >
          <option value="">Any year</option>
          {years.map((y) => (
            <option key={y} value={y}>
              {y}
            </option>
          ))}
        </Select>
      </FilterGroup>

      <FilterGroup title="Minimum rating">
        <Slider
          label="Rating"
          min={0}
          max={10}
          step={0.5}
          value={selected.minRating}
          onChange={(v) => setParam("minRating", v > 0 ? String(v) : null)}
          format={(v) => (v === 0 ? "Any" : `${v.toFixed(1)}+`)}
        />
      </FilterGroup>

      <FilterGroup title="Genres">
        <div className="flex flex-wrap gap-1.5">
          {genres.map((g) => (
            <Chip
              key={g.slug}
              active={selected.genres.includes(g.slug)}
              onClick={() => toggleMulti("genres", g.slug)}
            >
              {g.name}
            </Chip>
          ))}
        </div>
      </FilterGroup>

      {activeCount > 0 && (
        <Button variant="outline" className="w-full" onClick={reset}>
          <RotateCcw className="h-3.5 w-3.5" />
          Clear {activeCount} filter{activeCount === 1 ? "" : "s"}
        </Button>
      )}
    </div>
  );

  if (variant === "drawer") {
    return (
      <Drawer open={open} onClose={() => onOpenChange?.(false)} title="Filters" side="bottom">
        <div className="p-5">{body}</div>
      </Drawer>
    );
  }

  return <div className="space-y-6">{body}</div>;
}

function FilterGroup({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div>
      <h3 className="mb-2.5 text-[11px] font-semibold uppercase tracking-wider text-faint">
        {title}
      </h3>
      {children}
    </div>
  );
}

function Chip({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      aria-pressed={active}
      onClick={onClick}
      className={cn(
        "rounded-lg border px-2.5 py-1.5 text-[12px] font-medium transition-colors duration-150",
        active
          ? "border-transparent bg-accent text-accent-fg"
          : "border-[var(--line)] text-muted hover:border-[var(--line-strong)] hover:text-fg",
      )}
    >
      {children}
    </button>
  );
}

/** Compact chip row shown above the grid on desktop. */
export function ActiveFilterChips({
  genres,
}: {
  genres: { name: string; slug: string }[];
}) {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();

  const chips: { key: string; value: string; label: string }[] = [];
  for (const key of ["genres", "type", "status"] as const) {
    const raw = searchParams.get(key);
    if (!raw) continue;
    for (const value of raw.split(",")) {
      const label =
        key === "genres"
          ? genres.find((g) => g.slug === value)?.name ?? value
          : titleCase(value);
      chips.push({ key, value, label });
    }
  }
  const year = searchParams.get("year");
  if (year) chips.push({ key: "year", value: year, label: year });
  const minRating = searchParams.get("minRating");
  if (minRating) chips.push({ key: "minRating", value: minRating, label: `${minRating}+ rating` });

  if (!chips.length) return null;

  function remove(key: string, value: string) {
    const params = new URLSearchParams(searchParams.toString());
    if (key === "year" || key === "minRating") {
      params.delete(key);
    } else {
      const next = (params.get(key) ?? "").split(",").filter((v) => v && v !== value);
      if (next.length) params.set(key, next.join(","));
      else params.delete(key);
    }
    params.delete("page");
    router.push(`${pathname}?${params.toString()}`, { scroll: false });
  }

  return (
    <div className="flex flex-wrap items-center gap-2">
      {chips.map((chip) => (
        <button
          key={`${chip.key}-${chip.value}`}
          onClick={() => remove(chip.key, chip.value)}
          className="group inline-flex items-center gap-1.5 rounded-lg bg-surface-3 px-2.5 py-1.5 text-[12px] text-fg transition-colors hover:bg-surface-2"
        >
          {chip.label}
          <X className="h-3 w-3 text-faint transition-colors group-hover:text-fg" />
        </button>
      ))}
    </div>
  );
}

/** Mobile-only trigger that opens the drawer. */
export function FilterTrigger({ activeCount }: { activeCount: number }) {
  return (
    <Badge tone={activeCount ? "accent" : "neutral"} className="gap-1.5 px-2.5 py-1.5">
      <SlidersHorizontal className="h-3.5 w-3.5" />
      Filters
      {activeCount > 0 && <span className="font-mono">{activeCount}</span>}
    </Badge>
  );
}
