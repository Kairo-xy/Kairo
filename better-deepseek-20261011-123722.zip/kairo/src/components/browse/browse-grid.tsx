"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { useSearchParams } from "next/navigation";
import { Loader2 } from "lucide-react";
import { SeriesCard, SeriesCardSkeleton } from "@/components/series/series-card";
import { EmptyState } from "@/components/ui";
import { api } from "@/lib/api-client";
import type { Series } from "@/lib/types";

interface BrowseGridProps {
  initialItems: Series[];
  initialPage: number;
  totalPages: number;
}

/**
 * Infinite grid.
 *
 * The first page arrives from the server component (fast paint, SEO-visible),
 * subsequent pages are fetched on intersection. The sentinel is `rootMargin`'d
 * so the next page is usually decoded before it scrolls into view.
 */
export function BrowseGrid({ initialItems, initialPage, totalPages }: BrowseGridProps) {
  const searchParams = useSearchParams();
  const [items, setItems] = useState(initialItems);
  const [page, setPage] = useState(initialPage);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const sentinel = useRef<HTMLDivElement>(null);

  const queryKey = searchParams.toString();

  // Any filter change resets the grid to the server-rendered first page.
  useEffect(() => {
    setItems(initialItems);
    setPage(initialPage);
    setError(null);
  }, [queryKey, initialItems, initialPage]);

  const loadMore = useCallback(async () => {
    if (loading || page >= totalPages) return;

    setLoading(true);
    setError(null);
    try {
      const params = new URLSearchParams(queryKey);
      params.set("page", String(page + 1));
      const res = await api.series(
        Object.fromEntries(params) as Record<string, never>,
      );
      setItems((prev) => {
        const seen = new Set(prev.map((s) => s.id));
        return [...prev, ...res.items.filter((s) => !seen.has(s.id))];
      });
      setPage(res.page);
    } catch {
      setError("Couldn't load more. Check your connection and try again.");
    } finally {
      setLoading(false);
    }
  }, [loading, page, totalPages, queryKey]);

  useEffect(() => {
    const el = sentinel.current;
    if (!el) return;

    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0]?.isIntersecting) void loadMore();
      },
      { rootMargin: "600px 0px" },
    );

    observer.observe(el);
    return () => observer.disconnect();
  }, [loadMore]);

  if (!items.length) {
    return (
      <EmptyState
        title="Nothing matches those filters"
        description="Try widening the year range, clearing a genre, or lowering the minimum rating."
      />
    );
  }

  return (
    <div>
      <div className="grid grid-cols-2 gap-x-3 gap-y-6 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6">
        {items.map((series, i) => (
          <SeriesCard key={series.id} series={series} priority={i < 6} />
        ))}
      </div>

      {loading && (
        <div className="mt-6 grid grid-cols-2 gap-x-3 gap-y-6 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6">
          {Array.from({ length: 6 }).map((_, i) => (
            <SeriesCardSkeleton key={i} />
          ))}
        </div>
      )}

      {error && (
        <p className="mt-6 text-center text-[13px] text-danger" role="alert">
          {error}
        </p>
      )}

      {page < totalPages ? (
        <div ref={sentinel} className="flex justify-center py-10" aria-hidden>
          <Loader2 className="h-5 w-5 animate-spin text-faint" />
        </div>
      ) : (
        <p className="py-10 text-center text-[12px] text-faint">
          That's everything — {items.length} series.
        </p>
      )}
    </div>
  );
}
