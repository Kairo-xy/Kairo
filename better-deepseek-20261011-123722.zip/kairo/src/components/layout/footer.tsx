import Link from "next/link";

const COLUMNS = [
  {
    title: "Read",
    links: [
      { href: "/browse", label: "Browse all" },
      { href: "/browse?sort=latest", label: "Recently updated" },
      { href: "/browse?sort=rating", label: "Top rated" },
      { href: "/browse?type=WEBTOON", label: "Webtoons" },
    ],
  },
  {
    title: "Account",
    links: [
      { href: "/library", label: "My library" },
      { href: "/profile", label: "Profile" },
      { href: "/login", label: "Sign in" },
      { href: "/register", label: "Create account" },
    ],
  },
  {
    title: "About",
    links: [
      { href: "/about", label: "About kairo" },
      { href: "/dmca", label: "DMCA" },
      { href: "/terms", label: "Terms" },
      { href: "/privacy", label: "Privacy" },
    ],
  },
];

export function Footer() {
  return (
    <footer className="mt-20 border-t border-[var(--line)] pb-24 md:pb-10">
      <div className="mx-auto max-w-[1600px] px-4 py-12 sm:px-6">
        <div className="grid gap-10 sm:grid-cols-2 lg:grid-cols-4">
          <div>
            <div className="flex items-center gap-2">
              <svg width="22" height="22" viewBox="0 0 64 64" aria-hidden>
                <rect width="64" height="64" rx="14" className="fill-surface-3" />
                <path d="M20 16v32" stroke="var(--accent)" strokeWidth="6" strokeLinecap="round" />
                <path
                  d="M44 16 28 32l16 16"
                  stroke="var(--fg)"
                  strokeWidth="6"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  fill="none"
                />
              </svg>
              <span className="font-semibold tracking-tight">kairo</span>
            </div>
            <p className="mt-3 max-w-xs text-[13px] leading-relaxed text-muted">
              A reader built for the medium. No pop-ups, no redirects, no nonsense.
            </p>
          </div>

          {COLUMNS.map((col) => (
            <div key={col.title}>
              <h3 className="text-[11px] font-semibold uppercase tracking-wider text-faint">
                {col.title}
              </h3>
              <ul className="mt-3 space-y-2">
                {col.links.map((l) => (
                  <li key={l.href}>
                    <Link
                      href={l.href}
                      className="text-[13px] text-muted transition-colors duration-150 hover:text-fg"
                    >
                      {l.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-10 flex flex-col gap-3 border-t border-[var(--line)] pt-6 text-[12px] text-faint sm:flex-row sm:items-center sm:justify-between">
          <p>© {new Date().getFullYear()} kairo. Demo content is generated for illustration.</p>
          <p>Built with Next.js, Tailwind and too much coffee.</p>
        </div>
      </div>
    </footer>
  );
}
