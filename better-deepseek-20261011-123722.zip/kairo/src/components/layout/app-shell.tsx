import type { ReactNode } from "react";
import { Header } from "./header";
import { Sidebar } from "./sidebar";
import { MobileNav } from "./mobile-nav";
import { Footer } from "./footer";
import { getSession } from "@/lib/auth";

/**
 * The chrome-wrapped layout used by every page except the reader.
 * Keeping it in the `(site)` route group means `/read/*` never mounts it.
 */
export async function AppShell({ children }: { children: ReactNode }) {
  const session = await getSession();

  return (
    <div className="min-h-dvh">
      <Header session={session} />

      <div className="mx-auto flex max-w-[1600px] gap-8 px-4 pb-20 sm:px-6 md:pb-0">
        <Sidebar />
        <main id="content" className="min-w-0 flex-1">
          {children}
        </main>
      </div>

      <Footer />
      <MobileNav />
    </div>
  );
}
