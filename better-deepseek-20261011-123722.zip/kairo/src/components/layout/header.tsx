"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { LogOut, Menu, Search, User } from "lucide-react";
import { useRouter } from "next/navigation";
import { Button, Drawer } from "@/components/ui";
import { ThemeToggle } from "./theme-toggle";
import { SearchCommand } from "@/components/search/search-command";
import { Sidebar } from "./sidebar";
import { cn } from "@/lib/utils";
import type { SessionPayload } from "@/lib/session";

export function Header({ session }: { session: SessionPayload | null }) {
  const [scrolled, setScrolled] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const router = useRouter();

  // Slightly denser header once the user starts scrolling — subtle, but it
  // buys back ~12px of vertical rhythm on a page that's mostly poster grid.
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // ⌘K / Ctrl+K opens search from anywhere.
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setSearchOpen(true);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  async function signOut() {
    await fetch("/api/auth/logout", { method: "POST" });
    router.push("/");
    router.refresh();
  }

  return (
    <>
      <header
        className={cn(
          "safe-top sticky top-0 z-50 border-b transition-colors duration-200",
          scrolled
            ? "border-[var(--line)] bg-[color-mix(in_srgb,var(--bg)_82%,transparent)] backdrop-blur-xl"
            : "border-transparent bg-transparent",
        )}
      >
        <div className="mx-auto flex h-[60px] max-w-[1600px] items-center gap-3 px-4 sm:px-6">
          <button
            onClick={() => setMenuOpen(true)}
            aria-label="Open navigation"
            className="rounded-lg p-2 text-muted transition-colors hover:bg-surface-2 hover:text-fg lg:hidden"
          >
            <Menu className="h-5 w-5" />
          </button>

          <Link href="/" className="flex items-center gap-2" aria-label="kairo home">
            <KairoMark />
            <span className="text-[17px] font-semibold tracking-tight">kairo</span>
          </Link>

          <nav className="ml-4 hidden items-center gap-1 lg:flex">
            <HeaderLink href="/browse">Browse</HeaderLink>
            <HeaderLink href="/browse?sort=latest">Latest</HeaderLink>
            <HeaderLink href="/library">Library</HeaderLink>
          </nav>

          <div className="flex-1" />

          <button
            onClick={() => setSearchOpen(true)}
            className="group flex h-9 items-center gap-2 rounded-xl border border-[var(--line)] bg-surface-2 px-3 text-muted transition-colors duration-150 hover:border-[var(--line-strong)] hover:text-fg sm:w-64"
            aria-label="Search series"
          >
            <Search className="h-4 w-4 shrink-0" />
            <span className="hidden flex-1 text-left text-[13px] sm:block">Search…</span>
            <kbd className="hidden rounded border border-[var(--line-strong)] px-1.5 py-0.5 font-mono text-[10px] text-faint sm:block">
              ⌘K
            </kbd>
          </button>

          <ThemeToggle />

          {session ? (
            <div className="flex items-center gap-1">
              <Link
                href="/profile"
                className="flex items-center gap-2 rounded-xl px-2 py-1.5 transition-colors hover:bg-surface-2"
              >
                <span className="grid h-7 w-7 place-items-center rounded-full bg-[var(--accent-soft)] text-[12px] font-semibold text-accent">
                  {session.username.slice(0, 1).toUpperCase()}
                </span>
                <span className="hidden text-[13px] font-medium sm:block">{session.username}</span>
              </Link>
              <button
                onClick={signOut}
                aria-label="Sign out"
                className="rounded-lg p-2 text-faint transition-colors hover:bg-surface-2 hover:text-fg"
              >
                <LogOut className="h-4 w-4" />
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <Button variant="ghost" size="sm" asChild={false} className="hidden sm:inline-flex">
                <Link href="/login">Sign in</Link>
              </Button>
              <Link href="/register">
                <Button size="sm">Join</Button>
              </Link>
            </div>
          )}
        </div>
      </header>

      <SearchCommand open={searchOpen} onOpenChange={setSearchOpen} />

      <Drawer open={menuOpen} onClose={() => setMenuOpen(false)} side="left">
        <div className="p-4">
          <Link href="/" className="mb-6 flex items-center gap-2 px-2" onClick={() => setMenuOpen(false)}>
            <KairoMark />
            <span className="text-[17px] font-semibold tracking-tight">kairo</span>
          </Link>
          <div onClick={() => setMenuOpen(false)}>
            <Sidebar />
          </div>
          {!session && (
            <div className="mt-4 flex gap-2 px-2">
              <Link href="/login" className="flex-1">
                <Button variant="outline" className="w-full">
                  Sign in
                </Button>
              </Link>
              <Link href="/register" className="flex-1">
                <Button className="w-full">Join</Button>
              </Link>
            </div>
          )}
        </div>
      </Drawer>
    </>
  );
}

function HeaderLink({ href, children }: { href: string; children: React.ReactNode }) {
  return (
    <Link
      href={href}
      className="rounded-lg px-3 py-2 text-[13px] font-medium text-muted transition-colors duration-150 hover:bg-surface-2 hover:text-fg"
    >
      {children}
    </Link>
  );
}

function KairoMark() {
  return (
    <svg width="24" height="24" viewBox="0 0 64 64" aria-hidden className="shrink-0">
      <rect width="64" height="64" rx="14" className="fill-surface-3" />
      <path d="M20 16v32" stroke="var(--accent)" strokeWidth="6" strokeLinecap="round" />
      <path
        d="M44 16 28 32l16 16"
        stroke="var(--fg)"
        strokeWidth="6"
        strokeLinecap="round"
        strokeLinejoin="round"
        fill="none"
      />
    </svg>
  );
}
