"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { BookMarked, Compass, Home, Library, Settings, TrendingUp } from "lucide-react";
import { cn } from "@/lib/utils";

const NAV = [
  { href: "/", label: "Home", icon: Home },
  { href: "/browse", label: "Browse", icon: Compass },
  { href: "/browse?sort=popular", label: "Trending", icon: TrendingUp },
  { href: "/library", label: "Library", icon: Library },
  { href: "/library?tab=PLAN_TO_READ", label: "Plan to Read", icon: BookMarked },
];

const GENRE_LINKS = [
  { href: "/browse?genres=action", label: "Action" },
  { href: "/browse?genres=romance", label: "Romance" },
  { href: "/browse?genres=fantasy", label: "Fantasy" },
  { href: "/browse?genres=drama", label: "Drama" },
  { href: "/browse?genres=comedy", label: "Comedy" },
  { href: "/browse?genres=horror", label: "Horror" },
];

export function Sidebar() {
  const pathname = usePathname();

  return (
    <aside className="hidden w-60 shrink-0 lg:block">
      <nav className="sticky top-[68px] space-y-6 pr-2">
        <ul className="space-y-0.5">
          {NAV.map(({ href, label, icon: Icon }) => {
            const base = href.split("?")[0];
            const active = pathname === base && !href.includes("?");
            return (
              <li key={href}>
                <Link
                  href={href}
                  className={cn(
                    "flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-colors duration-150",
                    active
                      ? "bg-[var(--accent-soft)] text-accent"
                      : "text-muted hover:bg-surface-2 hover:text-fg",
                  )}
                >
                  <Icon className="h-[18px] w-[18px]" strokeWidth={2} />
                  {label}
                </Link>
              </li>
            );
          })}
        </ul>

        <div>
          <h3 className="px-3 pb-2 text-[11px] font-semibold uppercase tracking-wider text-faint">
            Genres
          </h3>
          <ul className="space-y-0.5">
            {GENRE_LINKS.map(({ href, label }) => (
              <li key={href}>
                <Link
                  href={href}
                  className="block rounded-lg px-3 py-2 text-[13px] text-muted transition-colors duration-150 hover:bg-surface-2 hover:text-fg"
                >
                  {label}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        <div className="border-t border-[var(--line)] pt-4">
          <Link
            href="/profile"
            className="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-muted transition-colors duration-150 hover:bg-surface-2 hover:text-fg"
          >
            <Settings className="h-[18px] w-[18px]" strokeWidth={2} />
            Settings
          </Link>
        </div>
      </nav>
    </aside>
  );
}
