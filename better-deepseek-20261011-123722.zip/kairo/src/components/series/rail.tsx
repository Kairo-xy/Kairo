"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import Link from "next/link";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { SeriesCard } from "./series-card";
import { cn } from "@/lib/utils";
import type { Series } from "@/lib/types";

interface RailProps {
  title: string;
  href?: string;
  series: Series[];
  className?: string;
}

/** Horizontally scrolling shelf with arrow affordances on pointer devices. */
export function Rail({ title, href, series, className }: RailProps) {
  const scroller = useRef<HTMLDivElement>(null);
  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(false);

  const update = useCallback(() => {
    const el = scroller.current;
    if (!el) return;
    setCanScrollLeft(el.scrollLeft > 8);
    setCanScrollRight(el.scrollLeft + el.clientWidth < el.scrollWidth - 8);
  }, []);

  useEffect(() => {
    update();
    const el = scroller.current;
    if (!el) return;
    el.addEventListener("scroll", update, { passive: true });
    window.addEventListener("resize", update);
    return () => {
      el.removeEventListener("scroll", update);
      window.removeEventListener("resize", update);
    };
  }, [update]);

  function nudge(direction: 1 | -1) {
    const el = scroller.current;
    if (!el) return;
    el.scrollBy({ left: direction * el.clientWidth * 0.85, behavior: "smooth" });
  }

  if (!series.length) return null;

  return (
    <section className={cn("relative", className)}>
      <div className="mb-3 flex items-end justify-between gap-4">
        <h2 className="text-[17px] font-semibold tracking-tight">{title}</h2>
        {href && (
          <Link
            href={href}
            className="text-[12px] font-medium text-muted transition-colors hover:text-accent"
          >
            View all
          </Link>
        )}
      </div>

      <div className="group/rail relative">
        <div
          ref={scroller}
          className="rail-scroll -mx-1 flex gap-3 overflow-x-auto px-1 pb-1"
          role="list"
        >
          {series.map((s, i) => (
            <div
              key={s.id}
              role="listitem"
              className="w-[132px] shrink-0 sm:w-[148px] lg:w-[164px]"
            >
              <SeriesCard series={s} priority={i < 4} />
            </div>
          ))}
        </div>

        {canScrollLeft && (
          <RailArrow direction="left" onClick={() => nudge(-1)} />
        )}
        {canScrollRight && (
          <RailArrow direction="right" onClick={() => nudge(1)} />
        )}
      </div>
    </section>
  );
}

function RailArrow({
  direction,
  onClick,
}: {
  direction: "left" | "right";
  onClick: () => void;
}) {
  const Icon = direction === "left" ? ChevronLeft : ChevronRight;
  return (
    <button
      onClick={onClick}
      aria-label={direction === "left" ? "Scroll left" : "Scroll right"}
      className={cn(
        "absolute top-[38%] z-10 hidden h-10 w-10 -translate-y-1/2 place-items-center",
        "rounded-full border border-[var(--line)] bg-[color-mix(in_srgb,var(--bg)_88%,transparent)]",
        "text-fg shadow-lg backdrop-blur-md transition-all duration-150",
        "opacity-0 hover:scale-105 group-hover/rail:opacity-100 md:grid",
        direction === "left" ? "-left-3" : "-right-3",
      )}
    >
      <Icon className="h-5 w-5" />
    </button>
  );
}
