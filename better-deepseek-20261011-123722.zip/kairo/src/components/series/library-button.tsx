"use client";

import { useEffect, useState } from "react";
import { Bookmark, Check, ChevronDown } from "lucide-react";
import { Button } from "@/components/ui";
import { cn } from "@/lib/utils";
import { api } from "@/lib/api-client";
import {
  getGuestLibraryStatus,
  removeGuestLibraryEntry,
  setGuestLibraryStatus,
} from "@/lib/reading-store";
import type { LibraryStatus } from "@/lib/types";

const OPTIONS: { value: LibraryStatus; label: string }[] = [
  { value: "READING", label: "Reading" },
  { value: "PLAN_TO_READ", label: "Plan to read" },
  { value: "COMPLETED", label: "Completed" },
  { value: "ON_HOLD", label: "On hold" },
  { value: "DROPPED", label: "Dropped" },
];

/**
 * Library membership control.
 *
 * Signed-in users hit the API; guests write to localStorage. The optimistic
 * update is the same code path in both cases, which keeps the component from
 * sprouting conditionals.
 */
export function LibraryButton({
  seriesId,
  isAuthenticated,
}: {
  seriesId: string;
  isAuthenticated: boolean;
}) {
  const [status, setStatus] = useState<LibraryStatus | null>(null);
  const [open, setOpen] = useState(false);
  const [pending, setPending] = useState(false);

  useEffect(() => {
    if (!isAuthenticated) {
      setStatus(getGuestLibraryStatus(seriesId));
      return;
    }

    let cancelled = false;
    api
      .listLibrary()
      .then((res) => {
        if (cancelled) return;
        const entries = res.items as { seriesId: string; status: LibraryStatus }[];
        setStatus(entries.find((e) => e.seriesId === seriesId)?.status ?? null);
      })
      .catch(() => {
        /* non-fatal: the button just stays in its default state */
      });

    return () => {
      cancelled = true;
    };
  }, [seriesId, isAuthenticated]);

  async function apply(next: LibraryStatus) {
    setPending(true);
    const previous = status;
    setStatus(next);
    setOpen(false);

    try {
      if (isAuthenticated) {
        await api.setLibrary(seriesId, next);
      } else {
        setGuestLibraryStatus(seriesId, next);
      }
    } catch {
      setStatus(previous); // roll back
    } finally {
      setPending(false);
    }
  }

  async function remove() {
    setPending(true);
    const previous = status;
    setStatus(null);
    setOpen(false);

    try {
      if (isAuthenticated) {
        await api.removeLibrary(seriesId);
      } else {
        removeGuestLibraryEntry(seriesId);
      }
    } catch {
      setStatus(previous);
    } finally {
      setPending(false);
    }
  }

  const label = status ? OPTIONS.find((o) => o.value === status)?.label ?? "In library" : "Add to library";

  return (
    <div className="relative">
      <Button
        variant={status ? "secondary" : "outline"}
        onClick={() => setOpen((o) => !o)}
        disabled={pending}
        aria-haspopup="menu"
        aria-expanded={open}
      >
        {status ? <Check className="h-4 w-4" /> : <Bookmark className="h-4 w-4" />}
        {label}
        <ChevronDown className="h-3.5 w-3.5 opacity-60" />
      </Button>

      {open && (
        <>
          <button
            className="fixed inset-0 z-40 cursor-default"
            aria-label="Close menu"
            onClick={() => setOpen(false)}
          />
          <div
            role="menu"
            className="absolute right-0 z-50 mt-2 w-48 animate-slide-up overflow-hidden rounded-xl border border-[var(--line)] bg-surface p-1 shadow-2xl"
          >
            {OPTIONS.map((option) => (
              <button
                key={option.value}
                role="menuitem"
                onClick={() => apply(option.value)}
                className={cn(
                  "flex w-full items-center justify-between rounded-lg px-3 py-2 text-left text-[13px] transition-colors duration-150",
                  status === option.value
                    ? "bg-[var(--accent-soft)] text-accent"
                    : "text-muted hover:bg-surface-2 hover:text-fg",
                )}
              >
                {option.label}
                {status === option.value && <Check className="h-3.5 w-3.5" />}
              </button>
            ))}

            {status && (
              <>
                <div className="my-1 h-px bg-[var(--line)]" />
                <button
                  role="menuitem"
                  onClick={remove}
                  className="w-full rounded-lg px-3 py-2 text-left text-[13px] text-danger transition-colors duration-150 hover:bg-surface-2"
                >
                  Remove from library
                </button>
              </>
            )}
          </div>
        </>
      )}
    </div>
  );
}
