"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { ArrowDownUp, Check, Lock } from "lucide-react";
import { Button, EmptyState, Input } from "@/components/ui";
import { cn, formatChapterNumber, formatRelative } from "@/lib/utils";
import { getReadChapters, getProgress } from "@/lib/reading-store";
import type { Chapter } from "@/lib/types";

interface ChapterListProps {
  seriesId: string;
  chapters: Chapter[];
}

const PAGE_SIZE = 30;

export function ChapterList({ seriesId, chapters }: ChapterListProps) {
  const [order, setOrder] = useState<"desc" | "asc">("desc");
  const [query, setQuery] = useState("");
  const [limit, setLimit] = useState(PAGE_SIZE);
  const [read, setRead] = useState<Record<string, true>>({});
  const [currentChapterId, setCurrentChapterId] = useState<string | null>(null);

  // Read markers live in localStorage, so they can only be read after mount.
  useEffect(() => {
    const sync = () => {
      setRead(getReadChapters());
      setCurrentChapterId(getProgress(seriesId)?.chapterId ?? null);
    };
    sync();
    window.addEventListener("kairo:store", sync);
    window.addEventListener("storage", sync);
    return () => {
      window.removeEventListener("kairo:store", sync);
      window.removeEventListener("storage", sync);
    };
  }, [seriesId]);

  const filtered = useMemo(() => {
    const needle = query.trim().toLowerCase();
    const list = needle
      ? chapters.filter(
          (c) =>
            String(c.number).includes(needle) ||
            c.title.toLowerCase().includes(needle),
        )
      : chapters.slice();
    return order === "desc" ? list : list.reverse();
  }, [chapters, query, order]);

  const visible = filtered.slice(0, limit);

  if (!chapters.length) {
    return (
      <EmptyState
        title="No chapters yet"
        description="This series hasn't published its first chapter. Follow it and you'll see updates here."
      />
    );
  }

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center gap-2">
        <div className="min-w-[180px] flex-1">
          <Input
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              setLimit(PAGE_SIZE);
            }}
            placeholder="Find a chapter…"
            aria-label="Filter chapters"
            className="h-9 text-[13px]"
          />
        </div>
        <Button
          variant="outline"
          size="sm"
          onClick={() => setOrder((o) => (o === "desc" ? "asc" : "desc"))}
          aria-label={`Sort ${order === "desc" ? "ascending" : "descending"}`}
        >
          <ArrowDownUp className="h-3.5 w-3.5" />
          {order === "desc" ? "Newest first" : "Oldest first"}
        </Button>
      </div>

      <ul className="divide-y divide-[var(--line)] overflow-hidden rounded-xl border border-[var(--line)] bg-surface">
        {visible.map((chapter) => {
          const isRead = Boolean(read[chapter.id]);
          const isCurrent = chapter.id === currentChapterId;

          return (
            <li key={chapter.id}>
              <Link
                href={`/read/${chapter.id}`}
                className={cn(
                  "flex items-center gap-3 px-3.5 py-3 transition-colors duration-150",
                  "hover:bg-surface-2",
                  isCurrent && "bg-[var(--accent-soft)]",
                )}
              >
                <span
                  className={cn(
                    "grid h-8 w-8 shrink-0 place-items-center rounded-lg font-mono text-[12px] font-medium",
                    isRead
                      ? "bg-[rgba(62,207,142,0.14)] text-success"
                      : isCurrent
                        ? "bg-accent text-accent-fg"
                        : "bg-surface-3 text-muted",
                  )}
                  aria-hidden
                >
                  {isRead ? <Check className="h-4 w-4" /> : formatChapterNumber(chapter.number)}
                </span>

                <div className="min-w-0 flex-1">
                  <p
                    className={cn(
                      "truncate text-[13px] font-medium",
                      isRead ? "text-muted" : "text-fg",
                    )}
                  >
                    {chapter.title}
                  </p>
                  <p className="mt-0.5 text-[11px] text-faint">
                    {formatRelative(chapter.publishedAt)} · {chapter.pageCount} pages
                  </p>
                </div>

                {chapter.isLocked && (
                  <Lock className="h-3.5 w-3.5 shrink-0 text-faint" aria-label="Locked" />
                )}

                {isCurrent && (
                  <span className="shrink-0 rounded-md bg-accent px-1.5 py-0.5 text-[10px] font-semibold text-accent-fg">
                    READING
                  </span>
                )}
              </Link>
            </li>
          );
        })}
      </ul>

      {limit < filtered.length && (
        <Button
          variant="outline"
          className="w-full"
          onClick={() => setLimit((l) => l + PAGE_SIZE)}
        >
          Load {Math.min(PAGE_SIZE, filtered.length - limit)} more
        </Button>
      )}

      {filtered.length === 0 && (
        <p className="py-8 text-center text-[13px] text-faint">
          No chapters match “{query}”.
        </p>
      )}
    </div>
  );
}
