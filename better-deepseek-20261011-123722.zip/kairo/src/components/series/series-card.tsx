import Image from "next/image";
import Link from "next/link";
import { Star } from "lucide-react";
import { cn, formatCompact, formatChapterNumber, formatRating } from "@/lib/utils";
import type { Series } from "@/lib/types";

const STATUS_LABEL: Record<Series["status"], string> = {
  ONGOING: "Ongoing",
  COMPLETED: "Completed",
  HIATUS: "Hiatus",
  CANCELLED: "Cancelled",
};

const TYPE_LABEL: Record<Series["type"], string> = {
  MANGA: "Manga",
  MANHWA: "Manhwa",
  MANHUA: "Manhua",
  WEBTOON: "Webtoon",
};

interface SeriesCardProps {
  series: Series;
  priority?: boolean;
  className?: string;
}

/**
 * 2:3 poster card.
 *
 * The cover is the only image; everything else is text so the hover overlay is
 * cheap. `next/image` handles blur-up via `placeholder="blur"` once you supply
 * `blurDataURL` from the CDN — for the demo we let the browser do it.
 */
export function SeriesCard({ series, priority = false, className }: SeriesCardProps) {
  return (
    <Link
      href={`/series/${series.slug}`}
      className={cn("group block focus-visible:outline-none", className)}
      aria-label={`${series.title}, ${series.chapterCount} chapters`}
    >
      <div className="relative aspect-poster overflow-hidden rounded-xl border border-[var(--line)] bg-surface-2">
        <Image
          src={series.coverUrl}
          alt=""
          fill
          sizes="(max-width: 640px) 45vw, (max-width: 1024px) 22vw, 180px"
          priority={priority}
          loading={priority ? undefined : "lazy"}
          className="object-cover transition-transform duration-500 ease-smooth group-hover:scale-[1.04]"
        />

        {/* Rating badge — always visible, it's the fastest signal. */}
        <div className="absolute left-2 top-2 flex items-center gap-1 rounded-lg bg-[rgba(0,0,0,0.66)] px-1.5 py-1 backdrop-blur-sm">
          <Star className="h-3 w-3 fill-[var(--warn)] text-[var(--warn)]" />
          <span className="font-mono text-[11px] font-medium leading-none text-white">
            {formatRating(series.rating)}
          </span>
        </div>

        {/* Hover overlay */}
        <div className="pointer-events-none absolute inset-0 flex flex-col justify-end bg-gradient-to-t from-[rgba(0,0,0,0.92)] via-[rgba(0,0,0,0.35)] to-transparent p-3 opacity-0 transition-opacity duration-200 group-hover:opacity-100 group-focus-visible:opacity-100">
          <p className="text-[12px] font-medium text-white">
            Ch. {formatChapterNumber(series.latestChapter)}
          </p>
          <p className="mt-0.5 text-[11px] text-white/60">{formatCompact(series.views)} views</p>
        </div>

        {series.status === "COMPLETED" && (
          <div className="absolute right-2 top-2 rounded-md bg-[rgba(62,207,142,0.9)] px-1.5 py-0.5 text-[10px] font-semibold text-[#062015]">
            END
          </div>
        )}
      </div>

      <div className="mt-2.5 space-y-1">
        <h3 className="line-clamp-2 text-[13px] font-medium leading-snug text-fg transition-colors duration-150 group-hover:text-accent">
          {series.title}
        </h3>
        <p className="flex items-center gap-1.5 text-[11px] text-faint">
          <span>{TYPE_LABEL[series.type]}</span>
          <span aria-hidden>·</span>
          <span>{STATUS_LABEL[series.status]}</span>
        </p>
      </div>
    </Link>
  );
}

export function SeriesCardSkeleton() {
  return (
    <div className="space-y-2.5">
      <div className="aspect-poster animate-pulse rounded-xl bg-surface-2" />
      <div className="h-3.5 w-4/5 animate-pulse rounded bg-surface-2" />
      <div className="h-3 w-2/5 animate-pulse rounded bg-surface-2" />
    </div>
  );
}
