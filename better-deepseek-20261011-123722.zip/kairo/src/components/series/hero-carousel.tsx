"use client";

import { useCallback, useEffect, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { BookOpen, ChevronLeft, ChevronRight, Star } from "lucide-react";
import { Button } from "@/components/ui";
import { cn, formatCompact, formatRating } from "@/lib/utils";
import { usePrefersReducedMotion } from "@/hooks/use-media-query";
import type { Series } from "@/lib/types";

const ROTATE_MS = 7000;

/**
 * Full-bleed featured carousel.
 *
 * Autoplay is suspended on hover, on focus, on tab-hidden, and entirely when
 * the user prefers reduced motion.
 */
export function HeroCarousel({ series }: { series: Series[] }) {
  const [index, setIndex] = useState(0);
  const [paused, setPaused] = useState(false);
  const reducedMotion = usePrefersReducedMotion();

  const next = useCallback(() => setIndex((i) => (i + 1) % series.length), [series.length]);
  const prev = useCallback(
    () => setIndex((i) => (i - 1 + series.length) % series.length),
    [series.length],
  );

  useEffect(() => {
    if (paused || reducedMotion || series.length < 2) return;

    const onVisibility = () => setPaused(document.hidden);
    document.addEventListener("visibilitychange", onVisibility);

    const timer = setInterval(next, ROTATE_MS);
    return () => {
      clearInterval(timer);
      document.removeEventListener("visibilitychange", onVisibility);
    };
  }, [paused, reducedMotion, next, series.length]);

  if (!series.length) return null;
  const active = series[index];

  return (
    <section
      className="relative overflow-hidden rounded-2xl border border-[var(--line)] bg-surface"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
      onFocusCapture={() => setPaused(true)}
      onBlurCapture={() => setPaused(false)}
      aria-roledescription="carousel"
      aria-label="Featured series"
    >
      {/* Backdrop */}
      <div className="absolute inset-0">
        {series.map((s, i) => (
          <Image
            key={s.id}
            src={s.bannerUrl}
            alt=""
            fill
            priority={i === 0}
            sizes="100vw"
            className={cn(
              "object-cover transition-opacity duration-700 ease-smooth",
              i === index ? "opacity-100" : "opacity-0",
            )}
          />
        ))}
        <div className="absolute inset-0 bg-gradient-to-t from-[var(--bg)] via-[rgba(11,11,15,0.72)] to-[rgba(11,11,15,0.28)]" />
        <div className="absolute inset-0 bg-gradient-to-r from-[rgba(11,11,15,0.9)] via-transparent to-transparent" />
      </div>

      {/* Content */}
      <div className="relative flex min-h-[380px] flex-col justify-end gap-4 p-6 sm:min-h-[440px] sm:p-10 lg:min-h-[500px] lg:max-w-3xl lg:p-14">
        <div className="animate-fade-in" key={active.id}>
          <div className="mb-3 flex flex-wrap items-center gap-2 text-[12px]">
            <span className="rounded-md bg-accent px-2 py-0.5 font-semibold text-accent-fg">
              Featured
            </span>
            <span className="flex items-center gap-1 text-white/70">
              <Star className="h-3.5 w-3.5 fill-[var(--warn)] text-[var(--warn)]" />
              <span className="font-mono">{formatRating(active.rating)}</span>
            </span>
            <span className="text-white/50">·</span>
            <span className="text-white/70">{formatCompact(active.views)} reads</span>
            <span className="text-white/50">·</span>
            <span className="text-white/70">{active.chapterCount} chapters</span>
          </div>

          <h1 className="text-balance text-3xl font-semibold leading-[1.1] tracking-tight sm:text-4xl lg:text-5xl">
            {active.title}
          </h1>

          <p className="mt-3 line-clamp-3 max-w-2xl text-pretty text-[14px] leading-relaxed text-white/70">
            {active.description}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <Link href={`/series/${active.slug}`}>
            <Button size="lg">
              <BookOpen className="h-4 w-4" />
              Start reading
            </Button>
          </Link>
          <Link href={`/series/${active.slug}`}>
            <Button size="lg" variant="outline" className="border-white/25 text-white hover:bg-white/10">
              Details
            </Button>
          </Link>
        </div>

        {/* Dots */}
        <div className="mt-2 flex items-center gap-2">
          <button
            onClick={prev}
            aria-label="Previous featured series"
            className="grid h-8 w-8 place-items-center rounded-full border border-white/20 text-white/80 transition-colors hover:bg-white/10"
          >
            <ChevronLeft className="h-4 w-4" />
          </button>
          <button
            onClick={next}
            aria-label="Next featured series"
            className="grid h-8 w-8 place-items-center rounded-full border border-white/20 text-white/80 transition-colors hover:bg-white/10"
          >
            <ChevronRight className="h-4 w-4" />
          </button>

          <div className="ml-2 flex items-center gap-1.5" role="tablist" aria-label="Slide">
            {series.map((s, i) => (
              <button
                key={s.id}
                role="tab"
                aria-selected={i === index}
                aria-label={`Go to ${s.title}`}
                onClick={() => setIndex(i)}
                className={cn(
                  "h-1.5 rounded-full transition-all duration-300",
                  i === index ? "w-6 bg-accent" : "w-1.5 bg-white/30 hover:bg-white/50",
                )}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
