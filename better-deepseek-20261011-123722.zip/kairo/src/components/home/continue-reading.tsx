"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { Play } from "lucide-react";
import { getContinueReading } from "@/lib/reading-store";
import { formatChapterNumber, formatRelative } from "@/lib/utils";
import type { ReadingProgressEntry } from "@/lib/types";

/**
 * "Continue reading" — the single most-used surface on the site.
 *
 * Progress for signed-in users is mirrored into localStorage by the reader, so
 * this reads from one place regardless of auth state and renders instantly
 * (no waterfall, no spinner).
 */
export function ContinueReadingRail() {
  const [entries, setEntries] = useState<ReadingProgressEntry[]>([]);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    const sync = () => setEntries(getContinueReading(18));
    sync();
    setHydrated(true);
    window.addEventListener("kairo:store", sync);
    window.addEventListener("storage", sync);
    return () => {
      window.removeEventListener("kairo:store", sync);
      window.removeEventListener("storage", sync);
    };
  }, []);

  if (!hydrated || entries.length === 0) return null;

  return (
    <section>
      <div className="mb-3 flex items-end justify-between gap-4">
        <h2 className="text-[17px] font-semibold tracking-tight">Continue reading</h2>
        <Link
          href="/library"
          className="text-[12px] font-medium text-muted transition-colors hover:text-accent"
        >
          Library
        </Link>
      </div>

      <div className="rail-scroll -mx-1 flex gap-3 overflow-x-auto px-1 pb-1">
        {entries.map((entry) => {
          const progress = entry.totalPages
            ? Math.round(((entry.page + 1) / entry.totalPages) * 100)
            : 0;

          return (
            <Link
              key={entry.seriesId}
              href={`/read/${entry.chapterId}`}
              className="group w-[260px] shrink-0 overflow-hidden rounded-xl border border-[var(--line)] bg-surface transition-colors duration-150 hover:border-[var(--line-strong)] sm:w-[300px]"
            >
              <div className="flex gap-3 p-3">
                <div className="relative h-[84px] w-14 shrink-0 overflow-hidden rounded-lg border border-[var(--line)] bg-surface-2">
                  <Image
                    src={entry.coverUrl}
                    alt=""
                    fill
                    sizes="56px"
                    className="object-cover"
                  />
                </div>

                <div className="min-w-0 flex-1">
                  <p className="truncate text-[13px] font-medium leading-snug">
                    {entry.seriesTitle}
                  </p>
                  <p className="mt-0.5 text-[11px] text-faint">
                    Ch. {formatChapterNumber(entry.chapterNumber)} · page {entry.page + 1}
                  </p>

                  <div className="mt-2.5 h-1 w-full overflow-hidden rounded-full bg-surface-3">
                    <div
                      className="h-full rounded-full bg-accent transition-[width] duration-300"
                      style={{ width: `${Math.max(4, progress)}%` }}
                    />
                  </div>

                  <p className="mt-1.5 text-[10px] text-faint">
                    {progress}% · {formatRelative(entry.updatedAt)}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-1.5 border-t border-[var(--line)] px-3 py-2 text-[11px] font-medium text-accent">
                <Play className="h-3 w-3 fill-current" />
                Resume
              </div>
            </Link>
          );
        })}
      </div>
    </section>
  );
}
