import { NextResponse, type NextRequest } from "next/server";
import { SESSION_COOKIE, decodeSession } from "@/lib/session";

/**
 * Route protection.
 * `/admin` requires role ADMIN; everything else just requires a session.
 */
const PROTECTED = ["/library", "/profile"];
const ADMIN_ONLY = ["/admin"];

export function middleware(req: NextRequest) {
  const { pathname, search } = req.nextUrl;
  const raw = req.cookies.get(SESSION_COOKIE)?.value;
  const session = raw ? decodeSession(raw) : null;

  const needsAdmin = ADMIN_ONLY.some((p) => pathname.startsWith(p));
  const needsAuth = needsAdmin || PROTECTED.some((p) => pathname.startsWith(p));

  if (needsAuth && !session) {
    const url = req.nextUrl.clone();
    url.pathname = "/login";
    url.search = `?next=${encodeURIComponent(pathname + search)}`;
    return NextResponse.redirect(url);
  }

  if (needsAdmin && session?.role !== "ADMIN") {
    const url = req.nextUrl.clone();
    url.pathname = "/";
    url.search = "";
    return NextResponse.redirect(url);
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/admin/:path*", "/library/:path*", "/profile/:path*"],
};
