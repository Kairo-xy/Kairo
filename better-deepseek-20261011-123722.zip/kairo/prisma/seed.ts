/**
 * Seeds Postgres from the deterministic demo catalog in src/lib/data.ts.
 * Run with: npm run db:seed
 */
import { PrismaClient } from "@prisma/client";
import { ALL_SERIES, getChaptersForSeries } from "../src/lib/data";

const prisma = new PrismaClient();

async function main() {
  console.log("→ clearing existing catalog…");
  await prisma.seriesGenre.deleteMany();
  await prisma.page.deleteMany();
  await prisma.chapter.deleteMany();
  await prisma.series.deleteMany();
  await prisma.genre.deleteMany();

  console.log("→ seeding genres…");
  const { GENRES } = await import("../src/lib/data");
  for (const g of GENRES) {
    await prisma.genre.upsert({
      where: { slug: g.slug },
      update: {},
      create: { name: g.name, slug: g.slug },
    });
  }
  const genreRows = await prisma.genre.findMany();
  const genreBySlug = new Map(genreRows.map((g) => [g.slug, g.id]));

  console.log(`→ seeding ${ALL_SERIES.length} series…`);
  for (const s of ALL_SERIES) {
    const chapters = getChaptersForSeries(s.id);

    await prisma.series.create({
      data: {
        id: s.id,
        slug: s.slug,
        title: s.title,
        altTitles: s.altTitles,
        description: s.description,
        coverUrl: s.coverUrl,
        bannerUrl: s.bannerUrl,
        author: s.author,
        artist: s.artist,
        type: s.type,
        status: s.status,
        releaseYear: s.releaseYear,
        rating: s.rating,
        ratingCount: s.ratingCount,
        views: s.views,
        featured: s.featured ?? false,
        genres: {
          create: s.genres
            .map((slug) => genreBySlug.get(slug))
            .filter((id): id is string => Boolean(id))
            .map((genreId) => ({ genreId })),
        },
        chapters: {
          create: chapters.map((c) => ({
            id: c.id,
            number: c.number,
            title: c.title,
            publishedAt: new Date(c.publishedAt),
            pageCount: c.pageCount,
            pages: {
              create: Array.from({ length: c.pageCount }, (_, i) => ({
                index: i,
                imageUrl: `https://picsum.photos/seed/${c.id}-${i}/800/1200`,
                width: 800,
                height: 1200,
              })),
            },
          })),
        },
      },
    });
  }

  const counts = await prisma.series.count();
  console.log(`✓ done — ${counts} series seeded.`);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
